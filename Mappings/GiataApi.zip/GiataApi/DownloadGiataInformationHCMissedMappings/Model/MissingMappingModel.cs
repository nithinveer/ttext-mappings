﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DownloadGiataInformationHCMissedMappings.Model
{
    public class MissingMappingModel
    {
        public int HotelStaticId { get; set; }
        public int GdsId { get; set; }
        public string AccommodationId { get; set; }
        public string SupplierHotelName { get; set; }
        public string GatewayCode { get; set; }
        public string GdsResortCode { get; set; }
        public string GdsResortName { get; set; }
        public string SupplierAddressLineOne { get; set; }
        public string SupplierAddressLineTwo { get; set; }
        public string SupplierAddressLineThree { get; set; }
        public string SupplierLatitude { get; set; }
        public string SupplierLongitude { get; set; }
        public int GiataId { get; set; }
        public string GiataHotelName { get; set; }
        public string CityName { get; set; }
        public string CountryCode { get; set; }
        public string AddressLine1 { get; set; }
        public string AddressLine2 { get; set; }
        public string AddressLine3 { get; set; }
        public string Latitude { get; set; }
        public string Longitude { get; set; }
        public int IndexFlag { get; set; }
        public int IgnoreMerge { get; set; }
    }
}
