﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DownloadGiataInfoTtssNoContentExport.Model
{
    public class TtssNoContentModel
    {
        public string HotelName { get; set; }
        public int Rating { get; set; }
        public string SupplierCode { get; set; }
        public string AirportCode { get; set; }
        public string SupplierHotelId { get; set; }
        public DateTime CreatedDateTime { get; set; }
        public DateTime LastModifiedDateTime { get; set; }
        public int GdsId { get; set; }
        public string ProviderCode { get; set; }
    }
}
