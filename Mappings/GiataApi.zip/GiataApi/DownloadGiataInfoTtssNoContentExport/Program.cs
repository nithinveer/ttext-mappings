﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using DownloadGiataInfoTtssNoContentExport.Model;

namespace DownloadGiataInfoTtssNoContentExport
{
    class Program
    {
        static void Main(string[] args)
        {
            string ttssNoContentExportConnectionString = ConfigurationManager.ConnectionStrings["TtssNoContentExport_ConnectionString"].ConnectionString;

            if (string.IsNullOrEmpty(ttssNoContentExportConnectionString) ||
                string.IsNullOrWhiteSpace(ttssNoContentExportConnectionString))
            {
                Console.WriteLine("TtssNoContentExport_ConnectionString is null or empty or white space.");
                return;
            }

            string ttssNoContentExportSpName = ConfigurationManager.AppSettings["SPForTtssNoContentExportList"];

            if (string.IsNullOrEmpty(ttssNoContentExportSpName) || string.IsNullOrWhiteSpace(ttssNoContentExportSpName))
            {
                Console.WriteLine("SPForTtssNoContentExportList is null or empty or white space.");
                return;
            }

            List<TtssNoContentModel> ttssNoContentList = GetTtssNoContentList(ttssNoContentExportConnectionString,
                ttssNoContentExportSpName);

            if (ttssNoContentList == null || ttssNoContentList.Count == 0)
            {
                Console.WriteLine("SPForTtssNoContentExportList returned zero records");
                return;
            }

            int numberOfItemsPerThread = 0;
            Int32.TryParse(ConfigurationManager.AppSettings["NumberOfItemsPerThread"], out numberOfItemsPerThread);

            int quotient = 0;
            int numberOfThreads = Math.DivRem(ttssNoContentList.Count, numberOfItemsPerThread, out quotient);

            numberOfThreads = quotient == 0 ? numberOfThreads : numberOfThreads + 1;

            List<Task> tasksCreated = new List<Task>();

            for (int loopIndex = 0; loopIndex < numberOfThreads; loopIndex++)
            {
                List<TtssNoContentModel> recordsToBeProcessedInThisThread = ttssNoContentList.Skip(loopIndex * numberOfItemsPerThread).Take(numberOfItemsPerThread).ToList();

                int index = loopIndex;

                tasksCreated.Add(Task.Factory.StartNew(() =>
                {
                    DownloadGiataHeaderInformationForTtssNoContent(recordsToBeProcessedInThisThread, ttssNoContentExportConnectionString, index);
                }));
            }



            while (tasksCreated.Count > 0)
            {
                int taskIndex = Task.WaitAny(tasksCreated.ToArray());

                if (tasksCreated[taskIndex].Exception == null)
                {
                    Console.WriteLine($"TaskIndex#: {taskIndex} has been completed.");
                }
                else
                {
                    foreach (Exception exception in tasksCreated[taskIndex].Exception.InnerExceptions)
                    {
                        Console.WriteLine($"TaskIndex#: {taskIndex} has failed with the following exception. Message: {exception.Message}");
                    }

                }
                tasksCreated.RemoveAt(taskIndex);
            }

            if (tasksCreated.Count == 0)
            {
                Console.WriteLine("===============================================");
                Console.WriteLine($"Downloading and insertion into db completed.");
                Console.WriteLine("===============================================");
            }

            Console.ReadLine();

        }

        private static void DownloadGiataHeaderInformationForTtssNoContent(
            List<TtssNoContentModel> recordsToBeProcessedInThisThread, string ttssNoContentExportConnectionString, int loopIndex)
        {
            Console.WriteLine($"{loopIndex} Fist SupplierHotelId: {recordsToBeProcessedInThisThread[0].SupplierHotelId}. Last SupplierHotelId: {recordsToBeProcessedInThisThread[recordsToBeProcessedInThisThread.Count - 1].SupplierHotelId}. Size: {recordsToBeProcessedInThisThread.Count}");


            DataTable ttssNoContentExportGhiDataTable = CreateTtssNoContentExportGhiDataTable();

            int numberOfRecordsTobeInsertedIntoDbInBulk = 0;
            Int32.TryParse(ConfigurationManager.AppSettings["NumberOfRecordsToBeInsertedInBulk"], out numberOfRecordsTobeInsertedIntoDbInBulk);

            int recordCount = 0;

            foreach (TtssNoContentModel ttssNoContentModel in recordsToBeProcessedInThisThread)
            {
                recordCount++;

                DataRow newTtssGhiDataRow = ttssNoContentExportGhiDataTable.NewRow();

                newTtssGhiDataRow["HotelName"] = ttssNoContentModel.HotelName;
                newTtssGhiDataRow["Rating"] = ttssNoContentModel.Rating;
                newTtssGhiDataRow["SupplierCode"] = ttssNoContentModel.SupplierCode;
                newTtssGhiDataRow["AirportCode"] = ttssNoContentModel.AirportCode;
                newTtssGhiDataRow["ProviderCode"] = ttssNoContentModel.ProviderCode;
                newTtssGhiDataRow["SupplierHotelId"] = ttssNoContentModel.SupplierHotelId;
                newTtssGhiDataRow["GdsId"] = ttssNoContentModel.GdsId;
                newTtssGhiDataRow["CreatedDate"] = DateTime.Now;

                if (string.IsNullOrEmpty(ttssNoContentModel.ProviderCode) || string.IsNullOrWhiteSpace(ttssNoContentModel.ProviderCode))
                {
                    ttssNoContentExportGhiDataTable.Rows.Add(newTtssGhiDataRow);
                    continue;
                }

                if (recordCount % numberOfRecordsTobeInsertedIntoDbInBulk == 0)
                {
                    Console.WriteLine($"Thread#: {loopIndex} has processed {recordCount} records.");

                    DataTable giataHeaderToBeInserted = ttssNoContentExportGhiDataTable.Copy();

                    ttssNoContentExportGhiDataTable.Rows.Clear();

                    BulkInsertIntoDb(giataHeaderToBeInserted, ttssNoContentExportConnectionString);
                }

                string giataUrl = ConfigurationManager.AppSettings["GiataUrl"];
                string url = String.Empty;

                if (ttssNoContentModel.GdsId == 10)
                {
                    url = String.Format(giataUrl, ttssNoContentModel.ProviderCode,
                        "H4U|" + ttssNoContentModel.SupplierHotelId);
                }
                else if (ttssNoContentModel.GdsId == 35)
                {
                    url = String.Format(giataUrl, ttssNoContentModel.ProviderCode,
                        ttssNoContentModel.SupplierHotelId.Split('|')[1]);
                }
                else
                {
                    url = String.Format(giataUrl, ttssNoContentModel.ProviderCode,
                        ttssNoContentModel.SupplierHotelId);
                }

                //Console.WriteLine($"Url -> {url}");
                Stream giataOutputStream = null;

                try
                {
                    HttpWebRequest httpWebRequest = (HttpWebRequest)WebRequest.Create(url);
                    httpWebRequest.Proxy = null;
                    httpWebRequest.Method = WebRequestMethods.Http.Get;
                    httpWebRequest.Credentials = new NetworkCredential(ConfigurationManager.AppSettings["GiataUserName"], ConfigurationManager.AppSettings["GiataPassword"]);
                    HttpWebResponse response = (HttpWebResponse)httpWebRequest.GetResponse();

                    giataOutputStream = response.GetResponseStream();
                }
                catch (Exception exception)
                {
                    newTtssGhiDataRow["ExceptionMessage"] =
                        $"Thread# {loopIndex} -> Url is: {url}. Failed for {ttssNoContentModel.SupplierHotelId} and exception is: {exception.Message}";

                    Console.WriteLine($"Thread# {loopIndex} -> Failed Url is: {url}");
                }

                if (giataOutputStream == null)
                {
                    newTtssGhiDataRow["GiataId"] = -1;
                }
                else if (giataOutputStream != null)
                {
                    XmlDocument giataXmlDocument = new XmlDocument();

                    giataXmlDocument.Load(giataOutputStream);

                    XmlNode propertyXmlNode = giataXmlDocument.SelectSingleNode("descendant::properties/property");

                    if (propertyXmlNode == null)
                    {
                        newTtssGhiDataRow["GiataId"] = 0;
                    }
                    else if (propertyXmlNode != null)
                    {
                        string giataIdString = ((XmlElement) propertyXmlNode).GetAttribute("giataId");
                        int giataId = 0;

                        Int32.TryParse(giataIdString, out giataId);

                        newTtssGhiDataRow["GiataId"] = giataId;
                        //Console.WriteLine($"{url} -> {hotelCompanyModel.Gdsid} : {hotelCompanyModel.Accommodationid} - {giataId}");

                        string giataLastUpdated = ((XmlElement) propertyXmlNode).GetAttribute("lastUpdate");

                        newTtssGhiDataRow["LastUpdatedString"] = giataLastUpdated;

                        string[] lastUpdatedParts = giataLastUpdated.Split('+');

                        DateTime dt = DateTime.Parse(lastUpdatedParts[0]);

                        TimeSpan offSet = TimeSpan.Parse(lastUpdatedParts[1]);

                        dt = dt.AddHours(offSet.Hours).AddMinutes(offSet.Minutes).AddSeconds(offSet.Seconds);

                        newTtssGhiDataRow["LastUpdated"] = dt;

                        XmlNode propertyNameXmlNode = propertyXmlNode.SelectSingleNode("descendant::name");

                        if (propertyNameXmlNode != null)
                        {
                            newTtssGhiDataRow["GiataName"] = propertyNameXmlNode.InnerText;
                            //giataResponse.Name = propertyNameXmlNode.InnerText;
                        }

                        XmlNode cityXmlNode = propertyXmlNode.SelectSingleNode("descendant::city");

                        if (cityXmlNode != null)
                        {
                            int cityId = 0;

                            Int32.TryParse(((XmlElement) cityXmlNode).GetAttribute("cityId"), out cityId);

                            newTtssGhiDataRow["GiataCityId"] = cityId;

                            //giataResponse.CityId = cityId;

                            newTtssGhiDataRow["GiataCity"] = cityXmlNode.InnerText;

                            //giataResponse.City = cityXmlNode.InnerText;
                        }

                        XmlNode countryXmlNode = propertyXmlNode.SelectSingleNode("descendant::country");

                        if (countryXmlNode != null)
                        {
                            newTtssGhiDataRow["GiataCountry"] = countryXmlNode.InnerText;
                            //giataResponse.Country = countryXmlNode.InnerText;
                        }

                        XmlNodeList addressXmlNodeList = propertyXmlNode.SelectNodes("descendant::addresses");

                        if (addressXmlNodeList != null && addressXmlNodeList.Count > 0)
                        {
                            foreach (XmlNode addressXmlNode in addressXmlNodeList)
                            {
                                XmlNodeList addressLineXmlNodeList =
                                    addressXmlNode.SelectNodes("descendant::addressLine");

                                if (addressLineXmlNodeList != null)
                                {
                                    foreach (XmlNode addressLineXmlNode in addressLineXmlNodeList)
                                    {
                                        string addressLineNumber =
                                            ((XmlElement) addressLineXmlNode).GetAttribute("addressLineNumber");

                                        if (addressLineNumber.Equals("1"))
                                        {
                                            newTtssGhiDataRow["GiataAddressLine1"] =
                                                addressLineXmlNode.InnerText;
                                            //giataAddress.AddressLineOne = addressLineXmlNode.InnerText;
                                        }
                                        else if (addressLineNumber.Equals("2"))
                                        {
                                            newTtssGhiDataRow["GiataAddressLine2"] =
                                                addressLineXmlNode.InnerText;
                                            //giataAddress.AddressLineTwo = addressLineXmlNode.InnerText;
                                        }
                                        else if (addressLineNumber.Equals("3"))
                                        {
                                            newTtssGhiDataRow["GiataAddressLine3"] =
                                                addressLineXmlNode.InnerText;
                                            //giataAddress.AddressLineThree = addressLineXmlNode.InnerText;
                                        }
                                        else if (addressLineNumber.Equals("4"))
                                        {
                                            newTtssGhiDataRow["GiataAddressLine4"] =
                                                addressLineXmlNode.InnerText;
                                            //giataAddress.AddressLineFour = addressLineXmlNode.InnerText;
                                        }
                                    }
                                }



                                XmlNode streetXmlNode = addressXmlNode.SelectSingleNode("descendant::street");

                                if (streetXmlNode != null)
                                {
                                    newTtssGhiDataRow["GiataStreet"] = streetXmlNode.InnerText;
                                    //giataAddress.Street = streetXmlNode.InnerText;
                                }

                                XmlNode streetNumberXmlNode = addressXmlNode.SelectSingleNode("descendant::streetNumber");

                                if (streetNumberXmlNode != null)
                                {
                                    newTtssGhiDataRow["GiataStreetNumber"] =
                                        streetNumberXmlNode.InnerText;
                                    //giataAddress.StreetNumber = streetNumberXmlNode.InnerText;
                                }

                                XmlNode cityNameXmlNode = addressXmlNode.SelectSingleNode("descendant::cityName");

                                if (cityNameXmlNode != null)
                                {
                                    newTtssGhiDataRow["GiataCityName"] = cityNameXmlNode.InnerText;
                                    //giataAddress.CityName = cityNameXmlNode.InnerText;
                                }

                                XmlNode postalCodeXmlNode = addressXmlNode.SelectSingleNode("descendant::postalCode");

                                if (postalCodeXmlNode != null)
                                {
                                    newTtssGhiDataRow["GiataPostalCode"] = postalCodeXmlNode.InnerText;
                                    //giataAddress.PoBox = postalCodeXmlNode.InnerText;
                                }

                                XmlNode addressCountryXmlNode = addressXmlNode.SelectSingleNode("descendant::country");

                                if (addressCountryXmlNode != null)
                                {
                                    newTtssGhiDataRow["GiataAddressCountry"] =
                                        addressCountryXmlNode.InnerText;
                                    //giataAddress.Country = addressCountryXmlNode.InnerText;
                                }
                            }
                        }

                        XmlNode latitudeXmlNode =
                            propertyXmlNode.SelectSingleNode("descendant::geoCodes/geoCode/latitude");

                        if (latitudeXmlNode != null)
                        {
                            newTtssGhiDataRow["GiataLatitude"] = latitudeXmlNode.InnerText;
                            //giataResponse.Latitude = latitudeXmlNode.InnerText;
                        }

                        XmlNode longitudeXmlNode =
                            propertyXmlNode.SelectSingleNode("descendant::geoCodes/geoCode/longitude");

                        if (longitudeXmlNode != null)
                        {
                            newTtssGhiDataRow["GiataLongitude"] = longitudeXmlNode.InnerText;
                            //giataResponse.Longitude = longitudeXmlNode.InnerText;
                        }
                    }
                }

                ttssNoContentExportGhiDataTable.Rows.Add(newTtssGhiDataRow);

                if (recordCount % numberOfRecordsTobeInsertedIntoDbInBulk == 0 ||
                    (recordsToBeProcessedInThisThread.Count - recordCount < numberOfRecordsTobeInsertedIntoDbInBulk &&
                     recordsToBeProcessedInThisThread.Count - 1 == recordCount))
                {
                    Console.WriteLine($"Thread#: {loopIndex} has processed {recordCount} records.");

                    DataTable giataHeaderToBeInserted = ttssNoContentExportGhiDataTable.Copy();

                    ttssNoContentExportGhiDataTable.Rows.Clear();

                    BulkInsertIntoDb(giataHeaderToBeInserted, ttssNoContentExportConnectionString);
                }
            }

            Console.WriteLine("-----------------------------------------------------------------------");
            Console.WriteLine($"Thread#: {loopIndex} Downloading and insertion of data completed.");
            Console.WriteLine("------------------------------------------------------------------------");
        }

        private static void BulkInsertIntoDb(DataTable ttssNoContentExportGhiDataTable,
            string ttssNoContentExportConnectionString)
        {
            using (SqlConnection sqlConnection = new SqlConnection(ttssNoContentExportConnectionString))
            {
                sqlConnection.Open();

                using (SqlBulkCopy sqlBulkCopy = new SqlBulkCopy(sqlConnection))
                {
                    sqlBulkCopy.DestinationTableName = ConfigurationManager.AppSettings["GiataHeaderInformationTableName"];

                    DbDataReader dbDataReader = new DataTableReader(ttssNoContentExportGhiDataTable);

                    sqlBulkCopy.WriteToServer(dbDataReader);
                }
            }
        }


        private static DataTable CreateTtssNoContentExportGhiDataTable()
        {
            DataTable ttssNoContentExportGhiDataTable = new DataTable();

            ttssNoContentExportGhiDataTable.Columns.Add("HotelName", typeof(string));
            ttssNoContentExportGhiDataTable.Columns.Add("Rating", typeof(int));
            ttssNoContentExportGhiDataTable.Columns.Add("SupplierCode", typeof(string));
            ttssNoContentExportGhiDataTable.Columns.Add("AirportCode", typeof(string));
            ttssNoContentExportGhiDataTable.Columns.Add("ProviderCode", typeof(string));
            ttssNoContentExportGhiDataTable.Columns.Add("SupplierHotelId", typeof(string));
            ttssNoContentExportGhiDataTable.Columns.Add("GdsId", typeof(int));
            ttssNoContentExportGhiDataTable.Columns.Add("GiataId", typeof(int));
            ttssNoContentExportGhiDataTable.Columns.Add("LastUpdatedString", typeof(string));
            ttssNoContentExportGhiDataTable.Columns.Add("LastUpdated", typeof(DateTime));
            ttssNoContentExportGhiDataTable.Columns.Add("GiataName", typeof(string));
            ttssNoContentExportGhiDataTable.Columns.Add("GiataCityId", typeof(Int32));
            ttssNoContentExportGhiDataTable.Columns.Add("GiataCity", typeof(string));
            ttssNoContentExportGhiDataTable.Columns.Add("GiataCountry", typeof(string));
            ttssNoContentExportGhiDataTable.Columns.Add("GiataAddressLine1", typeof(string));
            ttssNoContentExportGhiDataTable.Columns.Add("GiataAddressLine2", typeof(string));
            ttssNoContentExportGhiDataTable.Columns.Add("GiataAddressLine3", typeof(string));
            ttssNoContentExportGhiDataTable.Columns.Add("GiataAddressLine4", typeof(string));
            ttssNoContentExportGhiDataTable.Columns.Add("GiataStreet", typeof(string));
            ttssNoContentExportGhiDataTable.Columns.Add("GiataStreetNumber", typeof(string));
            ttssNoContentExportGhiDataTable.Columns.Add("GiataCityName", typeof(string));
            ttssNoContentExportGhiDataTable.Columns.Add("GiataPostalCode", typeof(string));
            ttssNoContentExportGhiDataTable.Columns.Add("GiataAddressCountry", typeof(string));
            ttssNoContentExportGhiDataTable.Columns.Add("GiataLatitude", typeof(string));
            ttssNoContentExportGhiDataTable.Columns.Add("GiataLongitude", typeof(string));
            ttssNoContentExportGhiDataTable.Columns.Add("CreatedDate", typeof(DateTime));
            ttssNoContentExportGhiDataTable.Columns.Add("ExceptionMessage", typeof(string));

            return ttssNoContentExportGhiDataTable;
        }

        private static List<TtssNoContentModel> GetTtssNoContentList(string ttssNoContentExportConnectionString, string ttssNoContentExportSpName)
        {
            List<TtssNoContentModel> ttssNoContentList = new List<TtssNoContentModel>();

            try
            {
                using (SqlConnection sqlConnection = new SqlConnection(ttssNoContentExportConnectionString))
                {
                    sqlConnection.Open();

                    SqlCommand sqlSelectCommand = new SqlCommand(ttssNoContentExportSpName, sqlConnection)
                    {
                        CommandType = CommandType.StoredProcedure
                    };

                    int insertRemainingItemsParams = 0;
                    Int32.TryParse(ConfigurationManager.AppSettings["InsertRemainingRecords"], out insertRemainingItemsParams);

                    SqlParameter sqlParameter = new SqlParameter("@InsertRemainingRecords", SqlDbType.Int)
                    {
                        Value = insertRemainingItemsParams
                    };

                    sqlSelectCommand.Parameters.Add(sqlParameter);

                    SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(sqlSelectCommand);

                    DataSet resultSet = new DataSet();

                    sqlDataAdapter.Fill(resultSet);

                    if (resultSet.Tables.Count > 0 && resultSet.Tables[0].Rows.Count > 0)
                    {
                        foreach (DataRow resultDataRow in resultSet.Tables[0].Rows)
                        {
                            TtssNoContentModel ttssNoContentModel = new TtssNoContentModel();

                            ttssNoContentModel.HotelName = resultDataRow["HotelName"] != DBNull.Value
                                ? resultDataRow["HotelName"].ToString()
                                : String.Empty;

                            ttssNoContentModel.AirportCode = resultDataRow["AirportCode"] != DBNull.Value
                                ? resultDataRow["AirportCode"].ToString()
                                : String.Empty;

                            ttssNoContentModel.CreatedDateTime = resultDataRow["CreatedDate"] != DBNull.Value
                                ? Convert.ToDateTime(resultDataRow["CreatedDate"].ToString())
                                : DateTime.MinValue;

                            ttssNoContentModel.GdsId = resultDataRow["GdsId"] != DBNull.Value
                                ? Convert.ToInt32(resultDataRow["GdsId"].ToString())
                                : -1;

                            ttssNoContentModel.LastModifiedDateTime = resultDataRow["LastModifiedDate"] != DBNull.Value
                                ? Convert.ToDateTime(resultDataRow["LastModifiedDate"].ToString())
                                : DateTime.MinValue;

                            ttssNoContentModel.ProviderCode = resultDataRow["ProviderCode"] != DBNull.Value
                                ? resultDataRow["ProviderCode"].ToString()
                                : String.Empty;

                            ttssNoContentModel.Rating = resultDataRow["Rating"] != DBNull.Value
                                ? Convert.ToInt32(resultDataRow["Rating"].ToString())
                                : -1;

                            ttssNoContentModel.SupplierCode = resultDataRow["SupplierCode"] != DBNull.Value
                                ? resultDataRow["SupplierCode"].ToString()
                                : String.Empty;

                            ttssNoContentModel.SupplierHotelId = resultDataRow["SupplierHotelId"] != DBNull.Value
                                ? resultDataRow["SupplierHotelId"].ToString()
                                : String.Empty;

                            ttssNoContentList.Add(ttssNoContentModel);
                        }
                    }
                }
            }
            catch (Exception exception)
            {
                Console.WriteLine($"Exception has occured while retrieving the TtssNoContentExport. Message: {exception.Message}");
            }


            return ttssNoContentList;
        }
    }
}
