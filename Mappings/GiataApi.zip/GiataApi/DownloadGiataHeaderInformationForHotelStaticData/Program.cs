﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Configuration;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using DownloadGiataHeaderInformationForHotelStaticData.Model;

namespace DownloadGiataHeaderInformationForHotelStaticData
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                List<HotelStaticDataModel> hotelStaticDataModels = GetHotelStaticDataModels();

                if (hotelStaticDataModels == null || hotelStaticDataModels.Count <= 0)
                {
                    Console.WriteLine($"Stored Procedure output is null or empty");
                    return;
                }

                Console.WriteLine($"============================================================");

                Console.WriteLine($"Total number of records to be downloaded: {hotelStaticDataModels.Count}");

                Console.WriteLine($"===========================================================");

                int numberOfItemsPerThread = 0;
                Int32.TryParse(ConfigurationManager.AppSettings["NumberOfItemsPerThread"], out numberOfItemsPerThread);

                int quotient = 0;
                int numberOfThreads = Math.DivRem(hotelStaticDataModels.Count, numberOfItemsPerThread, out quotient);

                numberOfThreads = quotient == 0 ? numberOfThreads : numberOfThreads + 1;

                List<Task> tasksCreated = new List<Task>();

                for (int loopIndex = 0; loopIndex < numberOfThreads; loopIndex++)
                {
                    List<HotelStaticDataModel> recordsToBeProcessed = hotelStaticDataModels.Skip(loopIndex * numberOfItemsPerThread).Take(numberOfItemsPerThread).ToList();

                    int threadIndex = loopIndex;

                    tasksCreated.Add(Task.Factory.StartNew(() =>
                    {
                        DownloadGiataHeaderInformationAndInsertIntoDb(recordsToBeProcessed, threadIndex);
                    }));
                }

                while (tasksCreated.Count > 0)
                {
                    int taskIndex = Task.WaitAny(tasksCreated.ToArray());

                    if (tasksCreated[taskIndex].Exception == null)
                    {
                        Console.WriteLine($"TaskIndex#: {taskIndex} has been completed.");
                    }
                    else
                    {
                        foreach (Exception exception in tasksCreated[taskIndex].Exception.InnerExceptions)
                        {
                            Console.WriteLine($"TaskIndex#: {taskIndex} has failed with the following exception. Message: {exception.Message}");
                        }

                    }
                    tasksCreated.RemoveAt(taskIndex);
                }

                if (tasksCreated.Count == 0)
                {
                    Console.WriteLine("===============================================");
                    Console.WriteLine($"Downloading and insertion into db completed.");
                    Console.WriteLine("===============================================");
                }

            }
            catch (Exception exception)
            {
                Console.WriteLine($"Exception occured in Main.\nMessage: {exception.Message}.\nStack Trace: {exception.StackTrace}");
            }
            Console.ReadLine();
        }

        private static void DownloadGiataHeaderInformationAndInsertIntoDb(
            List<HotelStaticDataModel> hotelStaticDataModels, int numberOfThread)
        {
            try
            {
                //Console.WriteLine($"{numberOfThread} Task started at: {DateTime.Now.ToString("G")}");
                Console.WriteLine($"{numberOfThread} First MHId: {hotelStaticDataModels[0].MasterHotelId}. Last MHId: {hotelStaticDataModels[hotelStaticDataModels.Count - 1].MasterHotelId}. Size: {hotelStaticDataModels.Count}");

                DataTable giataHeaderInformationDataTable = CreateGiataHeaderInformationDataTable();
                DataTable giataProviderInformationDataTable = CreateGiataProviderInformationHeaderTable();

                int recordCount = 0;

                int numberOfRecordsTobeInsertedIntoDbInBulk = 0;
                Int32.TryParse(ConfigurationManager.AppSettings["NumberOfRecordsToBeInsertedInBulk"], out numberOfRecordsTobeInsertedIntoDbInBulk);

                foreach (HotelStaticDataModel hotelStaticDataModel in hotelStaticDataModels)
                {
                    DataRow newGiataHeaderInformationDataRow = giataHeaderInformationDataTable.NewRow();

                    newGiataHeaderInformationDataRow["HotelStaticId"] = hotelStaticDataModel.HotelStaticId;
                    newGiataHeaderInformationDataRow["MasterHotelId"] = hotelStaticDataModel.MasterHotelId;
                    newGiataHeaderInformationDataRow["MasterHotelName"] = hotelStaticDataModel.MasterHotelName;
                    newGiataHeaderInformationDataRow["MasterResortId"] = hotelStaticDataModel.MasterResortId;
                    newGiataHeaderInformationDataRow["MasterResortName"] = hotelStaticDataModel.MasterResortName;
                    newGiataHeaderInformationDataRow["CountryName"] = hotelStaticDataModel.CountryName;
                    newGiataHeaderInformationDataRow["CountryCode"] = hotelStaticDataModel.CountryCode;
                    newGiataHeaderInformationDataRow["DestinationCode"] = hotelStaticDataModel.DestinationCode;
                    newGiataHeaderInformationDataRow["MasterLatitude"] = hotelStaticDataModel.MasterLatitude;
                    newGiataHeaderInformationDataRow["MasterLongitude"] = hotelStaticDataModel.MasterLongitude;
                    newGiataHeaderInformationDataRow["CityTown"] = hotelStaticDataModel.CityTown;
                    newGiataHeaderInformationDataRow["AddressLine1"] = hotelStaticDataModel.AddressLineOne;
                    newGiataHeaderInformationDataRow["AddressLine2"] = hotelStaticDataModel.AddressLineTwo;
                    newGiataHeaderInformationDataRow["AddressLine3"] = hotelStaticDataModel.AddressLineThree;
                    newGiataHeaderInformationDataRow["SupplierHotelName"] = hotelStaticDataModel.SupplierHotelName;

                    newGiataHeaderInformationDataRow["GdsId"] = hotelStaticDataModel.GdsId;
                    newGiataHeaderInformationDataRow["AccommodationId"] = hotelStaticDataModel.AccommodationId;
                    newGiataHeaderInformationDataRow["GateWayCode"] = hotelStaticDataModel.GatewayCode;
                    newGiataHeaderInformationDataRow["DestinationCode"] = hotelStaticDataModel.DestinationCode;
                    newGiataHeaderInformationDataRow["Deleted"] = hotelStaticDataModel.Deleted;

                    newGiataHeaderInformationDataRow["CreatedDate"] = DateTime.Now;
                    
                    if (String.IsNullOrWhiteSpace(hotelStaticDataModel.GiataProviderCode) || String.IsNullOrEmpty(hotelStaticDataModel.GiataProviderCode))
                    {
                        newGiataHeaderInformationDataRow["GiataId"] = -2;
                        recordCount++;
                        giataHeaderInformationDataTable.Rows.Add(newGiataHeaderInformationDataRow);

                        if (recordCount % numberOfRecordsTobeInsertedIntoDbInBulk == 0)
                        {

                            Console.WriteLine($"Thread#: {numberOfThread} has processed {recordCount} records.");

                            DataTable giataHeaderToBeInserted = giataHeaderInformationDataTable.Copy();
                            DataTable giataProviderToBeInserted = giataProviderInformationDataTable.Copy();

                            giataHeaderInformationDataTable.Rows.Clear();
                            giataProviderInformationDataTable.Rows.Clear();

                            BulkInsertIntoDb(giataHeaderToBeInserted, giataProviderToBeInserted, numberOfThread);
                        }
                        continue;
                    }
                    newGiataHeaderInformationDataRow["GiataProviderCode"] = hotelStaticDataModel.GiataProviderCode;

                    string giataUrl = ConfigurationManager.AppSettings["GiataUrl"];
                    string url = String.Empty;

                    if (hotelStaticDataModel.GdsId == 10)
                    {
                        url = String.Format(giataUrl, hotelStaticDataModel.GiataProviderCode,
                            "H4U|" + hotelStaticDataModel.AccommodationId);
                    }
                    else if (hotelStaticDataModel.GdsId == 35)
                    {
                        url = String.Format(giataUrl, hotelStaticDataModel.GiataProviderCode,
                            hotelStaticDataModel.AccommodationId.Split('|')[1]);
                    }
                    else
                    {
                        url = String.Format(giataUrl, hotelStaticDataModel.GiataProviderCode,
                            hotelStaticDataModel.AccommodationId);
                    }

                    Console.WriteLine($"Url is: {url}");

                    Stream giataOutputStream = null;

                    try
                    {
                        HttpWebRequest httpWebRequest = (HttpWebRequest)WebRequest.Create(url);
                        httpWebRequest.Proxy = null;
                        httpWebRequest.Method = WebRequestMethods.Http.Get;
                        httpWebRequest.Credentials = new NetworkCredential(ConfigurationManager.AppSettings["GiataUserName"], ConfigurationManager.AppSettings["GiataPassword"]);
                        HttpWebResponse response = (HttpWebResponse)httpWebRequest.GetResponse();

                        giataOutputStream = response.GetResponseStream();
                    }
                    catch (Exception exception)
                    {
                        newGiataHeaderInformationDataRow["ExceptionMessage"] =
                            $"Thread# {numberOfThread} -> Url is: {url}. Failed for {hotelStaticDataModel.HotelStaticId} and exception is: {exception.Message}";

                        Console.WriteLine($"Thread# {numberOfThread} -> Failed Url is: {url}");
                    }

                    if (giataOutputStream == null)
                    {
                        newGiataHeaderInformationDataRow["GiataId"] = -1;
                    }
                    else if (giataOutputStream != null)
                    {
                        XmlDocument giataXmlDocument = new XmlDocument();

                        giataXmlDocument.Load(giataOutputStream);

                        XmlNode propertyXmlNode = giataXmlDocument.SelectSingleNode("descendant::properties/property");

                        if (propertyXmlNode == null)
                        {
                            newGiataHeaderInformationDataRow["GiataId"] = 0;
                        }
                        else if (propertyXmlNode != null)
                        {
                            string giataIdString = ((XmlElement)propertyXmlNode).GetAttribute("giataId");
                            int giataId = 0;

                            Int32.TryParse(giataIdString, out giataId);

                            newGiataHeaderInformationDataRow["GiataId"] = giataId;
                            //Console.WriteLine($"{url} -> {hotelCompanyModel.Gdsid} : {hotelCompanyModel.Accommodationid} - {giataId}");

                            string giataLastUpdated = ((XmlElement)propertyXmlNode).GetAttribute("lastUpdate");

                            newGiataHeaderInformationDataRow["LastUpdatedString"] = giataLastUpdated;

                            string[] lastUpdatedParts = giataLastUpdated.Split('+');

                            DateTime dt = DateTime.Parse(lastUpdatedParts[0]);

                            TimeSpan offSet = TimeSpan.Parse(lastUpdatedParts[1]);

                            dt = dt.AddHours(offSet.Hours).AddMinutes(offSet.Minutes).AddSeconds(offSet.Seconds);

                            newGiataHeaderInformationDataRow["LastUpdated"] = dt;

                            XmlNode propertyNameXmlNode = propertyXmlNode.SelectSingleNode("descendant::name");

                            if (propertyNameXmlNode != null)
                            {
                                newGiataHeaderInformationDataRow["GiataName"] = propertyNameXmlNode.InnerText;
                                //giataResponse.Name = propertyNameXmlNode.InnerText;
                            }

                            XmlNode cityXmlNode = propertyXmlNode.SelectSingleNode("descendant::city");

                            if (cityXmlNode != null)
                            {
                                int cityId = 0;

                                Int32.TryParse(((XmlElement)cityXmlNode).GetAttribute("cityId"), out cityId);

                                newGiataHeaderInformationDataRow["GiataCityId"] = cityId;

                                //giataResponse.CityId = cityId;

                                newGiataHeaderInformationDataRow["GiataCity"] = cityXmlNode.InnerText;

                                //giataResponse.City = cityXmlNode.InnerText;
                            }

                            XmlNode countryXmlNode = propertyXmlNode.SelectSingleNode("descendant::country");

                            if (countryXmlNode != null)
                            {
                                newGiataHeaderInformationDataRow["GiataCountry"] = countryXmlNode.InnerText;
                                //giataResponse.Country = countryXmlNode.InnerText;
                            }

                            XmlNodeList addressXmlNodeList = propertyXmlNode.SelectNodes("descendant::addresses");

                            if (addressXmlNodeList != null && addressXmlNodeList.Count > 0)
                            {
                                foreach (XmlNode addressXmlNode in addressXmlNodeList)
                                {
                                    XmlNodeList addressLineXmlNodeList =
                                        addressXmlNode.SelectNodes("descendant::addressLine");

                                    if (addressLineXmlNodeList != null)
                                    {
                                        foreach (XmlNode addressLineXmlNode in addressLineXmlNodeList)
                                        {
                                            string addressLineNumber =
                                                ((XmlElement)addressLineXmlNode).GetAttribute("addressLineNumber");

                                            if (addressLineNumber.Equals("1"))
                                            {
                                                newGiataHeaderInformationDataRow["GiataAddressLine1"] = addressLineXmlNode.InnerText;
                                                //giataAddress.AddressLineOne = addressLineXmlNode.InnerText;
                                            }
                                            else if (addressLineNumber.Equals("2"))
                                            {
                                                newGiataHeaderInformationDataRow["GiataAddressLine2"] = addressLineXmlNode.InnerText;
                                                //giataAddress.AddressLineTwo = addressLineXmlNode.InnerText;
                                            }
                                            else if (addressLineNumber.Equals("3"))
                                            {
                                                newGiataHeaderInformationDataRow["GiataAddressLine3"] = addressLineXmlNode.InnerText;
                                                //giataAddress.AddressLineThree = addressLineXmlNode.InnerText;
                                            }
                                            else if (addressLineNumber.Equals("4"))
                                            {
                                                newGiataHeaderInformationDataRow["GiataAddressLine4"] = addressLineXmlNode.InnerText;
                                                //giataAddress.AddressLineFour = addressLineXmlNode.InnerText;
                                            }
                                        }
                                    }



                                    XmlNode streetXmlNode = addressXmlNode.SelectSingleNode("descendant::street");

                                    if (streetXmlNode != null)
                                    {
                                        newGiataHeaderInformationDataRow["GiataStreet"] = streetXmlNode.InnerText;
                                        //giataAddress.Street = streetXmlNode.InnerText;
                                    }

                                    XmlNode streetNumberXmlNode = addressXmlNode.SelectSingleNode("descendant::streetNumber");

                                    if (streetNumberXmlNode != null)
                                    {
                                        newGiataHeaderInformationDataRow["GiataStreetNumber"] = streetNumberXmlNode.InnerText;
                                        //giataAddress.StreetNumber = streetNumberXmlNode.InnerText;
                                    }

                                    XmlNode cityNameXmlNode = addressXmlNode.SelectSingleNode("descendant::cityName");

                                    if (cityNameXmlNode != null)
                                    {
                                        newGiataHeaderInformationDataRow["GiataCityName"] = cityNameXmlNode.InnerText;
                                        //giataAddress.CityName = cityNameXmlNode.InnerText;
                                    }

                                    XmlNode postalCodeXmlNode = addressXmlNode.SelectSingleNode("descendant::postalCode");

                                    if (postalCodeXmlNode != null)
                                    {
                                        newGiataHeaderInformationDataRow["GiataPostalCode"] = postalCodeXmlNode.InnerText;
                                        //giataAddress.PoBox = postalCodeXmlNode.InnerText;
                                    }

                                    XmlNode addressCountryXmlNode = addressXmlNode.SelectSingleNode("descendant::country");

                                    if (addressCountryXmlNode != null)
                                    {
                                        newGiataHeaderInformationDataRow["GiataAddressCountry"] = addressCountryXmlNode.InnerText;
                                        //giataAddress.Country = addressCountryXmlNode.InnerText;
                                    }
                                }
                            }

                            XmlNode latitudeXmlNode =
                                propertyXmlNode.SelectSingleNode("descendant::geoCodes/geoCode/latitude");

                            if (latitudeXmlNode != null)
                            {
                                newGiataHeaderInformationDataRow["GiataLatitude"] = latitudeXmlNode.InnerText;
                                //giataResponse.Latitude = latitudeXmlNode.InnerText;
                            }

                            XmlNode longitudeXmlNode =
                                propertyXmlNode.SelectSingleNode("descendant::geoCodes/geoCode/longitude");

                            if (longitudeXmlNode != null)
                            {
                                newGiataHeaderInformationDataRow["GiataLongitude"] = longitudeXmlNode.InnerText;
                                //giataResponse.Longitude = longitudeXmlNode.InnerText;
                            }

                            XmlNodeList providerCodeXmlNodeList =
                                propertyXmlNode.SelectNodes("descendant::propertyCodes/provider");

                            if (providerCodeXmlNodeList != null)
                            {
                                foreach (XmlNode providerCodeXmlNode in providerCodeXmlNodeList)
                                {
                                    string providerCode =
                                            ((XmlElement)providerCodeXmlNode).GetAttribute("providerCode");

                                    string providerType =
                                        ((XmlElement)providerCodeXmlNode).GetAttribute("providerType");


                                    XmlNodeList codeXmlNodeList = providerCodeXmlNode.SelectNodes("descendant::code");

                                    if (codeXmlNodeList != null)
                                    {
                                        foreach (XmlNode codeXmlNode in codeXmlNodeList)
                                        {

                                            DataRow newGiataProviderInformationDataRow =
                                                giataProviderInformationDataTable.NewRow();

                                            XmlNode valueXmlNode = codeXmlNode.SelectSingleNode("descendant::value");

                                            if (valueXmlNode != null)
                                            {
                                                newGiataProviderInformationDataRow["ProviderCode"] = providerCode;
                                                newGiataProviderInformationDataRow["ProviderType"] = providerType;
                                                
                                                
                                                newGiataProviderInformationDataRow["GiataId"] = giataId;
                                                newGiataProviderInformationDataRow["Value"] = valueXmlNode.InnerText;
                                                newGiataProviderInformationDataRow["CreatedDate"] = DateTime.Now;
                                                //giataProviderInfo.CodeValues.Add(valueXmlNode.InnerText);
                                            }
                                            giataProviderInformationDataTable.Rows.Add(newGiataProviderInformationDataRow);
                                        }
                                    }
                                }
                            }


                        }
                    }
                    recordCount++;
                    giataHeaderInformationDataTable.Rows.Add(newGiataHeaderInformationDataRow);

                    if (recordCount % numberOfRecordsTobeInsertedIntoDbInBulk == 0 || (hotelStaticDataModels.Count - recordCount < numberOfRecordsTobeInsertedIntoDbInBulk && hotelStaticDataModels.Count - 1 == recordCount))
                    {
                        Console.WriteLine($"Thread#: {numberOfThread} has processed {recordCount} records.");

                        DataTable giataHeaderToBeInserted = giataHeaderInformationDataTable.Copy();
                        DataTable giataProviderToBeInserted = giataProviderInformationDataTable.Copy();

                        giataHeaderInformationDataTable.Rows.Clear();
                        giataProviderInformationDataTable.Rows.Clear();

                        BulkInsertIntoDb(giataHeaderToBeInserted, giataProviderToBeInserted, numberOfThread);
                    }
                }

                Console.WriteLine("-----------------------------------------------------------------------");
                Console.WriteLine($"Thread#: {numberOfThread} Downloading and insertion of data completed.");
                Console.WriteLine("------------------------------------------------------------------------");

            }
            catch (Exception exception)
            {
                Console.WriteLine($"Thread#: {numberOfThread} exception is: {exception.Message}");
                throw new ApplicationException(exception.Message, exception.InnerException);
            }
        }

        private static void BulkInsertIntoDb(DataTable giataHeaderInformationDataTable,
            DataTable giataProviderInformationDataTable, int numberOfThread)
        {


            using (SqlConnection sqlConnection = new SqlConnection(ConfigurationManager.ConnectionStrings["DbConnectionString"].ConnectionString))
            {
                sqlConnection.Open();

                try
                {
                    using (SqlBulkCopy sqlBulkCopy = new SqlBulkCopy(sqlConnection))
                    {
                        sqlBulkCopy.DestinationTableName = ConfigurationManager.AppSettings["GiataHeaderInformationTable"];

                        DbDataReader dbDataReader = new DataTableReader(giataHeaderInformationDataTable);

                        sqlBulkCopy.WriteToServer(dbDataReader);
                    }
                }
                catch (Exception exception)
                {
                    Console.WriteLine($"Exception has occured while inserting into GiataHeaderInformation. Exception Message: {exception.Message}");
                }

                try
                {
                    using (SqlBulkCopy sqlBulkCopy = new SqlBulkCopy(sqlConnection))
                    {
                        sqlBulkCopy.DestinationTableName = ConfigurationManager.AppSettings["GiataProviderInformationTable"];

                        DbDataReader dbDataReader = new DataTableReader(giataProviderInformationDataTable);

                        sqlBulkCopy.WriteToServer(dbDataReader);
                    }
                }
                catch (Exception exception)
                {
                    Console.WriteLine($"Exception has occured while inserting into GiataProviderInformation. Exception Message: {exception.Message}");
                }
            }
            if (giataHeaderInformationDataTable.Rows.Count != 100)
            {
                Console.WriteLine(
                    $"Thread#: {numberOfThread} insertion into {ConfigurationManager.AppSettings["GiataHeaderInformationTable"]} completed for {giataHeaderInformationDataTable.Rows.Count} records in Header Information.");
            }
        }

        private static DataTable CreateGiataHeaderInformationDataTable()
        {
            DataTable giataHeaderDataTable = new DataTable();

            giataHeaderDataTable.Columns.Add("HotelStaticId", typeof(Int32));
            giataHeaderDataTable.Columns.Add("MasterHotelId", typeof(Int32));
            giataHeaderDataTable.Columns.Add("CorrectedMasterHotelId", typeof(Int32));
            giataHeaderDataTable.Columns.Add("GdsId", typeof(Int32));
            giataHeaderDataTable.Columns.Add("GdsName", typeof(string));
            giataHeaderDataTable.Columns.Add("GiataProviderCode", typeof(string));
            giataHeaderDataTable.Columns.Add("AccommodationId", typeof(string));
            giataHeaderDataTable.Columns.Add("GateWayCode", typeof(string));
            giataHeaderDataTable.Columns.Add("GdsResortCode", typeof(string));
            giataHeaderDataTable.Columns.Add("GdsResortName", typeof(string));
            giataHeaderDataTable.Columns.Add("MasterHotelName", typeof(string));
            giataHeaderDataTable.Columns.Add("SupplierHotelName", typeof(string));
            giataHeaderDataTable.Columns.Add("CountryName", typeof(string));
            giataHeaderDataTable.Columns.Add("CountryCode", typeof(string));
            giataHeaderDataTable.Columns.Add("DestinationCode", typeof(string));
            giataHeaderDataTable.Columns.Add("MasterLatitude", typeof(string));
            giataHeaderDataTable.Columns.Add("MasterLongitude", typeof(string));
            giataHeaderDataTable.Columns.Add("CityTown", typeof(string));
            giataHeaderDataTable.Columns.Add("AddressLine1", typeof(string));
            giataHeaderDataTable.Columns.Add("AddressLine2", typeof(string));
            giataHeaderDataTable.Columns.Add("AddressLine3", typeof(string));
            giataHeaderDataTable.Columns.Add("MasterResortId", typeof(int));
            giataHeaderDataTable.Columns.Add("MasterResortName", typeof(string));
            giataHeaderDataTable.Columns.Add("Deleted", typeof(bool));

            giataHeaderDataTable.Columns.Add("GiataId", typeof(Int32));
            giataHeaderDataTable.Columns.Add("CorrectedGiataId", typeof(Int32));

            giataHeaderDataTable.Columns.Add("LastUpdatedString", typeof(string));
            giataHeaderDataTable.Columns.Add("LastUpdated", typeof(DateTime));
            giataHeaderDataTable.Columns.Add("GiataName", typeof(string));
            giataHeaderDataTable.Columns.Add("GiataCityId", typeof(Int32));
            giataHeaderDataTable.Columns.Add("GiataCity", typeof(string));
            giataHeaderDataTable.Columns.Add("GiataCountry", typeof(string));
            giataHeaderDataTable.Columns.Add("GiataAddressLine1", typeof(string));
            giataHeaderDataTable.Columns.Add("GiataAddressLine2", typeof(string));
            giataHeaderDataTable.Columns.Add("GiataAddressLine3", typeof(string));
            giataHeaderDataTable.Columns.Add("GiataAddressLine4", typeof(string));
            giataHeaderDataTable.Columns.Add("GiataStreet", typeof(string));
            giataHeaderDataTable.Columns.Add("GiataStreetNumber", typeof(string));
            giataHeaderDataTable.Columns.Add("GiataCityName", typeof(string));
            giataHeaderDataTable.Columns.Add("GiataPostalCode", typeof(string));
            giataHeaderDataTable.Columns.Add("GiataAddressCountry", typeof(string));
            giataHeaderDataTable.Columns.Add("GiataLatitude", typeof(string));
            giataHeaderDataTable.Columns.Add("GiataLongitude", typeof(string));
            giataHeaderDataTable.Columns.Add("CreatedDate", typeof(DateTime));
            giataHeaderDataTable.Columns.Add("ExceptionMessage", typeof(string));

            return giataHeaderDataTable;
        }

        private static DataTable CreateGiataProviderInformationHeaderTable()
        {
            DataTable giataProviderDataTable = new DataTable();

            giataProviderDataTable.Columns.Add("GiataId", typeof(Int32));
            giataProviderDataTable.Columns.Add("CorrectedGdsId", typeof(Int32));
            giataProviderDataTable.Columns.Add("GdsId", typeof(Int32));
            giataProviderDataTable.Columns.Add("CorrectedSupplierHotelId", typeof(string));
            giataProviderDataTable.Columns.Add("GdsName", typeof(string));
            giataProviderDataTable.Columns.Add("CreatedDate", typeof(DateTime));
            giataProviderDataTable.Columns.Add("GdsCode", typeof(string));
            giataProviderDataTable.Columns.Add("ProviderCode", typeof(string));
            giataProviderDataTable.Columns.Add("ProviderType", typeof(string));
            giataProviderDataTable.Columns.Add("Value", typeof(string));

            return giataProviderDataTable;
        }

        private static List<HotelStaticDataModel> GetHotelStaticDataModels()
        {
            List<HotelStaticDataModel> hotelStaticDataModels = new List<HotelStaticDataModel>();

            try
            {
                using (
                    SqlConnection sqlConnection =
                        new SqlConnection(ConfigurationManager.ConnectionStrings["DbConnectionString"].ConnectionString))
                {
                    sqlConnection.Open();

                    SqlCommand sqlSelectCommand =
                        new SqlCommand(ConfigurationManager.AppSettings["RetrieveHotelCompanyForGiataDownloadSP"],
                            sqlConnection)
                        {
                            CommandType = CommandType.StoredProcedure
                        };

                    int insertRemainingParams = 0;
                    Int32.TryParse(ConfigurationManager.AppSettings["InsertRemainingParams"], out insertRemainingParams);

                    SqlParameter sqlParameter = new SqlParameter("@InsertRemainingParams", SqlDbType.Int)
                    {
                        Value = insertRemainingParams
                    };

                    sqlSelectCommand.Parameters.Add(sqlParameter);

                    SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(sqlSelectCommand);

                    DataSet resultDataSet = new DataSet();

                    sqlDataAdapter.Fill(resultDataSet);

                    if (resultDataSet.Tables.Count > 0)
                    {
                        if (resultDataSet.Tables[0].Rows.Count > 0)
                        {
                            foreach (DataRow dataRow in resultDataSet.Tables[0].Rows)
                            {
                                HotelStaticDataModel hotelStaticDataModel = new HotelStaticDataModel();

                                hotelStaticDataModel.GiataProviderCode = dataRow["GiataProviderCode"] != DBNull.Value
                                    ? dataRow["GiataProviderCode"].ToString()
                                    : String.Empty;

                                hotelStaticDataModel.AccommodationId = dataRow["AccommodationID"] != DBNull.Value
                                    ? dataRow["AccommodationID"].ToString()
                                    : String.Empty;

                                hotelStaticDataModel.AddressLineOne = dataRow["AddressLine1"] != DBNull.Value
                                    ? dataRow["AddressLine1"].ToString()
                                    : String.Empty;

                                hotelStaticDataModel.AddressLineTwo = dataRow["AddressLine2"] != DBNull.Value
                                    ? dataRow["AddressLine2"].ToString()
                                    : String.Empty;

                                hotelStaticDataModel.AddressLineThree = dataRow["AddressLine3"] != DBNull.Value
                                    ? dataRow["AddressLine3"].ToString()
                                    : String.Empty;

                                hotelStaticDataModel.CityTown = dataRow["CityTown"] != DBNull.Value
                                    ? dataRow["CityTown"].ToString()
                                    : String.Empty;

                                hotelStaticDataModel.CountryCode = dataRow["CountryCode"] != DBNull.Value
                                    ? dataRow["CountryCode"].ToString()
                                    : String.Empty;

                                hotelStaticDataModel.CountryName = dataRow["CountryName"] != DBNull.Value
                                    ? dataRow["CountryName"].ToString()
                                    : String.Empty;

                                hotelStaticDataModel.DestinationCode = dataRow["DestinationCode"] != DBNull.Value
                                    ? dataRow["DestinationCode"].ToString()
                                    : String.Empty;

                                hotelStaticDataModel.GatewayCode = dataRow["GatewayCode"] != DBNull.Value
                                    ? dataRow["GatewayCode"].ToString()
                                    : String.Empty;

                                hotelStaticDataModel.GdsId = dataRow["GdsId"] != DBNull.Value
                                    ? Convert.ToInt32(dataRow["GdsId"])
                                    : -1;

                                hotelStaticDataModel.GdsName = dataRow["GDSName"] != DBNull.Value
                                    ? dataRow["GDSName"].ToString()
                                    : String.Empty;

                                hotelStaticDataModel.GdsResortCode = dataRow["GdsResortCode"] != DBNull.Value
                                    ? dataRow["GdsResortCode"].ToString()
                                    : String.Empty;

                                hotelStaticDataModel.GdsResortName = dataRow["GdsResortName"] != DBNull.Value
                                    ? dataRow["GdsResortName"].ToString()
                                    : String.Empty;

                                hotelStaticDataModel.StarRating = dataRow["StarRating"] != DBNull.Value
                                    ? dataRow["StarRating"].ToString()
                                    : String.Empty;

                                hotelStaticDataModel.SupplierLatitude = dataRow["SupplierLatitude"] != DBNull.Value
                                    ? dataRow["SupplierLatitude"].ToString()
                                    : String.Empty;

                                hotelStaticDataModel.SupplierLongitude = dataRow["SupplierLongitude"] != DBNull.Value
                                    ? dataRow["SupplierLongitude"].ToString()
                                    : String.Empty;

                                hotelStaticDataModel.HotelStaticId = dataRow["HotelStaticID"] != DBNull.Value
                                    ? Convert.ToInt32(dataRow["HotelStaticID"])
                                    : -1;

                                hotelStaticDataModel.MasterHotelId = dataRow["MasterHotelID"] != DBNull.Value
                                    ? Convert.ToInt32(dataRow["MasterHotelID"])
                                    : -1;

                                hotelStaticDataModel.MasterHotelName = dataRow["MasterHotelName"] != DBNull.Value
                                    ? dataRow["MasterHotelName"].ToString()
                                    : String.Empty;

                                hotelStaticDataModel.MasterLatitude = dataRow["MasterLatitude"] != DBNull.Value
                                    ? dataRow["MasterLatitude"].ToString()
                                    : String.Empty;

                                hotelStaticDataModel.MasterLongitude = dataRow["MasterLongitude"] != DBNull.Value
                                    ? dataRow["MasterLongitude"].ToString()
                                    : String.Empty;

                                hotelStaticDataModel.SupplierHotelName = dataRow["SupplierHotelName"] != DBNull.Value
                                    ? dataRow["SupplierHotelName"].ToString()
                                    : String.Empty;

                                hotelStaticDataModel.MasterResortId = dataRow["MasterResortID"] != DBNull.Value
                                    ? Convert.ToInt32(dataRow["MasterResortID"])
                                    : -1;

                                hotelStaticDataModel.MasterResortName = dataRow["MasterResortName"] != DBNull.Value
                                    ? dataRow["MasterResortName"].ToString()
                                    : String.Empty;

                                hotelStaticDataModel.Deleted = dataRow["Deleted"] != DBNull.Value && Convert.ToBoolean(dataRow["Deleted"].ToString());

                                hotelStaticDataModels.Add(hotelStaticDataModel);
                            }
                        }
                    }
                }
            }
            catch (Exception exception)
            {
                Console.WriteLine($"GetHotelStaticDataModels. Exception: {exception.Message}");
            }

            return hotelStaticDataModels;
        }
    }
}
