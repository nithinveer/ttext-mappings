﻿using System;

namespace DownloadGiataHeaderInformationForHotelStaticData.Model
{
    public class HotelStaticDataModel
    {
        public int HotelStaticId { get; set; }
        public int MasterHotelId { get; set; }
        public int GdsId { get; set; }
        public string GiataProviderCode { get; set; }
        public string GdsName { get; set; }
        public string AccommodationId { get; set; }
        public string GatewayCode { get; set; }
        public string GdsResortCode { get; set; }
        public string GdsResortName { get; set; }
        public string StarRating { get; set; }
        public string SupplierLatitude { get; set; }
        public string SupplierLongitude { get; set; }
        public string MasterHotelName { get; set; }
        public string SupplierHotelName { get; set; }
        public string CountryName { get; set; }
        public string CountryCode { get; set; }
        public string DestinationCode { get; set; }
        public string MasterLatitude { get; set; }
        public string MasterLongitude { get; set; }
        public string CityTown { get; set; }
        public string AddressLineOne { get; set; }
        public string AddressLineTwo { get; set; }
        public string AddressLineThree { get; set; }
        public int MasterResortId { get; set; }
        public string MasterResortName { get; set; }
        public bool Deleted { get; set; }
    }
}
