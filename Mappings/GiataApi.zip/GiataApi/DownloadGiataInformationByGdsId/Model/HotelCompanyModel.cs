﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DownloadGiataInformationByGdsId.Model
{
    public class HotelCompanyModel
    {
        public int HotelStaticId { get; set; }//int
        public int MasterhotelId { get; set; }//int
        public int GdsId { get; set; }//int
        public string GdsName { get; set; }//nvarchar
        public string AccommodationId { get; set; }//nvarchar
        public string GatewayCode { get; set; }//nvarchar
        public string GdsResortCode { get; set; }//nvarchar
        public string GdsResortname { get; set; }//nvarchar
        public string MasterHotelName { get; set; }//nvarchar
        public string MasterResortName { get; set; }//nvarchar
        public string SupplierHotelName { get; set; }//nvarchar
        public string CountryName { get; set; }//nvarchar
        public string CountryCode { get; set; }//nvarchar
        public string DestinationCode { get; set; }//nvarchar
        public int MasterGiataCode { get; set; }//int
        public int TavHotelid { get; set; }//int
        public string Latitude { get; set; }//float
        public string Longitude { get; set; }//float
        public string CityTown { get; set; }//nvarchar
        public string Addressline1 { get; set; }//nvarchar
        public string Addressline2 { get; set; }//nvarchar
        public string Addressline3 { get; set; }//nvarchar
    }
}
