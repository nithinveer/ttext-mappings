﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using DownloadGiataInformationByGdsId.Model;

namespace DownloadGiataInformationByGdsId
{
    class Program
    {
        private static readonly Dictionary<int, string> _gdsIdToGiataProviderCode = new Dictionary<int, string>();

        private static readonly Dictionary<int, string> gdsIdToGdsName = new Dictionary<int, string>();

        static void Main(string[] args)
        {
            List<HotelCompanyModel> hotelCompanyModels = GetHotelCompanyModelList();

            if (hotelCompanyModels == null)
            {
                Console.WriteLine($"HotelCompanyModels is null.");
                return;
            }

            int numberOfItemsPerThread = 0;
            Int32.TryParse(ConfigurationManager.AppSettings["NumberOfItemsPerThread"], out numberOfItemsPerThread);

            int quotient = 0;
            int numberOfThreads = Math.DivRem(hotelCompanyModels.Count, numberOfItemsPerThread, out quotient);

            numberOfThreads = quotient == 0 ? numberOfThreads : numberOfThreads + 1;

            List<Task> tasksCreated = new List<Task>();

            for (int loopIndex = 0; loopIndex < numberOfThreads; loopIndex++)
            {
                List<HotelCompanyModel> recordsToBeProcessed = hotelCompanyModels.Skip(loopIndex * numberOfItemsPerThread).Take(numberOfItemsPerThread).ToList();

                int threadIndex = loopIndex;

                tasksCreated.Add(Task.Factory.StartNew(() =>
                {
                    DownloadGiataDataAndInsertIntoDb(recordsToBeProcessed, threadIndex);
                }));
            }

            while (tasksCreated.Count > 0)
            {
                int taskIndex = Task.WaitAny(tasksCreated.ToArray());

                if (tasksCreated[taskIndex].Exception == null)
                {
                    Console.WriteLine($"TaskIndex#: {taskIndex} has been completed.");
                }
                else
                {
                    foreach (Exception exception in tasksCreated[taskIndex].Exception.InnerExceptions)
                    {
                        Console.WriteLine($"TaskIndex#: {taskIndex} has failed with the following exception. Message: {exception.Message}");
                    }

                }
                tasksCreated.RemoveAt(taskIndex);
            }

            if (tasksCreated.Count == 0)
            {
                Console.WriteLine("===============================================");
                Console.WriteLine($"Downloading and insertion into db completed.");
                Console.WriteLine("===============================================");
            }

            Console.ReadLine();

        }

        private static void DownloadGiataDataAndInsertIntoDb(List<HotelCompanyModel> hotelCompanyModels, int numberOfThread)
        {
            List<string> status = new List<string>();
            try
            {
                //Console.WriteLine($"{numberOfThread} Task started at: {DateTime.Now.ToString("G")}");
                Console.WriteLine($"{numberOfThread} First MHId: {hotelCompanyModels[0].MasterhotelId}. Last MHId: {hotelCompanyModels[hotelCompanyModels.Count - 1].MasterhotelId}. Size: {hotelCompanyModels.Count}");

                DataTable giataHeaderInformationDataTable = CreateGiataHeaderInformationDataTable();

                DataTable giataProviderInformationDataTable = CreateGiataProviderInformationHeaderTable();

                List<string> failedUrlList = new List<string>();

                int recordCount = 0;

                int totalProcessedRecordCount = 0;

                int numberOfRecordsTobeInsertedIntoDbInBulk = 0;
                Int32.TryParse(ConfigurationManager.AppSettings["NumberOfRecordsToBeInsertedInBulk"], out numberOfRecordsTobeInsertedIntoDbInBulk);

                foreach (HotelCompanyModel hotelCompanyModel in hotelCompanyModels)
                {
                    DataRow newGiataHeaderInformationDataRow = giataHeaderInformationDataTable.NewRow();

                    //newGiataHeaderInformationDataRow["Serial"] = hotelCompanyModel.Serial;
                    newGiataHeaderInformationDataRow["HotelStaticId"] = hotelCompanyModel.HotelStaticId;
                    newGiataHeaderInformationDataRow["MasterHotelId"] = hotelCompanyModel.MasterhotelId;
                    newGiataHeaderInformationDataRow["MasterHotelName"] = hotelCompanyModel.MasterHotelName;
                    newGiataHeaderInformationDataRow["MasterResortName"] = hotelCompanyModel.MasterResortName;
                    newGiataHeaderInformationDataRow["MasterCountryName"] = hotelCompanyModel.CountryName;
                    newGiataHeaderInformationDataRow["MasterCountryCode"] = hotelCompanyModel.CountryCode;
                    newGiataHeaderInformationDataRow["MasterDestinationCode"] = hotelCompanyModel.DestinationCode;
                    newGiataHeaderInformationDataRow["MasterGiataCode"] = hotelCompanyModel.MasterGiataCode;
                    newGiataHeaderInformationDataRow["MasterLatitude"] = hotelCompanyModel.Latitude;
                    newGiataHeaderInformationDataRow["MasterLongitude"] = hotelCompanyModel.Longitude;
                    newGiataHeaderInformationDataRow["MasterCityTown"] = hotelCompanyModel.CityTown;
                    newGiataHeaderInformationDataRow["MasterAddressLine1"] = hotelCompanyModel.Addressline1;
                    newGiataHeaderInformationDataRow["SupplierHotelName"] = hotelCompanyModel.SupplierHotelName;

                    newGiataHeaderInformationDataRow["GdsId"] = hotelCompanyModel.GdsId;
                    newGiataHeaderInformationDataRow["AccommodationId"] = hotelCompanyModel.AccommodationId;
                    newGiataHeaderInformationDataRow["GateWayCode"] = hotelCompanyModel.GatewayCode;
                    newGiataHeaderInformationDataRow["DestinationCode"] = hotelCompanyModel.DestinationCode;
                    newGiataHeaderInformationDataRow["CreatedDate"] = DateTime.Now;
                    //if (recordCount == 202)
                    //{
                    //    break;
                    //}
                    if (!_gdsIdToGiataProviderCode.ContainsKey(hotelCompanyModel.GdsId))
                    {
                        //Console.WriteLine($"Skipping for AccomId:GdsId:MasterHotelId {hotelCompanyModel.Accommodationid + ":" + hotelCompanyModel.Gdsid + ":" + hotelCompanyModel.Masterhotelid}");
                        newGiataHeaderInformationDataRow["GiataId"] = -2;
                        recordCount++;
                        giataHeaderInformationDataTable.Rows.Add(newGiataHeaderInformationDataRow);

                        if (recordCount % numberOfRecordsTobeInsertedIntoDbInBulk == 0)// || (hotelCompanyModels.Count - recordCount < numberOfRecordsTobeInsertedIntoDbInBulk && hotelCompanyModels.Count - 1 == recordCount))
                        {

                            Console.WriteLine($"Thread#: {numberOfThread} has processed {recordCount} records at {DateTime.Now:G}.");

                            DataTable giataHeaderToBeInserted = giataHeaderInformationDataTable.Copy();
                            DataTable giataProviderToBeInserted = giataProviderInformationDataTable.Copy();

                            giataHeaderInformationDataTable.Rows.Clear();
                            giataProviderInformationDataTable.Rows.Clear();

                            BulkInsertIntoDb(giataHeaderToBeInserted, giataProviderToBeInserted, numberOfThread);
                        }
                        continue;
                    }
                    newGiataHeaderInformationDataRow["GiataProviderCode"] =
                        _gdsIdToGiataProviderCode[hotelCompanyModel.GdsId];

                    string giataUrl = ConfigurationManager.AppSettings["GiataUrl"];
                    string url = String.Empty;

                    if (hotelCompanyModel.GdsId == 10)
                    {
                        url = String.Format(giataUrl, _gdsIdToGiataProviderCode[hotelCompanyModel.GdsId],
                            hotelCompanyModel.GdsName + "|" + hotelCompanyModel.AccommodationId);
                    }
                    else if (hotelCompanyModel.GdsId == 35)
                    {
                        url = String.Format(giataUrl, _gdsIdToGiataProviderCode[hotelCompanyModel.GdsId],
                            hotelCompanyModel.AccommodationId.Split('|')[1]);
                    }
                    else if (hotelCompanyModel.GdsId != 10)
                    {
                        url = String.Format(giataUrl, _gdsIdToGiataProviderCode[hotelCompanyModel.GdsId],
                            hotelCompanyModel.AccommodationId);
                    }

                    //Console.WriteLine($"Url is -> {url}");
                    
                    Stream giataOutputStream = null;

                    try
                    {
                        HttpWebRequest httpWebRequest = (HttpWebRequest)WebRequest.Create(url);
                        httpWebRequest.Proxy = null;
                        httpWebRequest.Method = WebRequestMethods.Http.Get;
                        httpWebRequest.Credentials = new NetworkCredential(ConfigurationManager.AppSettings["GiataUserName"], ConfigurationManager.AppSettings["GiataPassword"]);
                        HttpWebResponse response = (HttpWebResponse)httpWebRequest.GetResponse();

                        giataOutputStream = response.GetResponseStream();
                    }
                    catch (Exception exception)
                    {
                        newGiataHeaderInformationDataRow["ExceptionMessage"] =
                            $"Thread# {numberOfThread} -> Url is: {url}. Failed for {hotelCompanyModel.HotelStaticId} and exception is: {exception.Message}";

                        Console.WriteLine($"Thread# {numberOfThread} -> Failed Url is: {url}");
                        failedUrlList.Add(url);
                    }

                    if (giataOutputStream == null)
                    {
                        newGiataHeaderInformationDataRow["GiataId"] = -1;
                    }
                    else if (giataOutputStream != null)
                    {
                        XmlDocument giataXmlDocument = new XmlDocument();

                        giataXmlDocument.Load(giataOutputStream);

                        XmlNode propertyXmlNode = giataXmlDocument.SelectSingleNode("descendant::properties/property");

                        if (propertyXmlNode == null)
                        {
                            newGiataHeaderInformationDataRow["GiataId"] = 0;
                        }
                        else if (propertyXmlNode != null)
                        {
                            string giataIdString = ((XmlElement)propertyXmlNode).GetAttribute("giataId");
                            int giataId = 0;

                            Int32.TryParse(giataIdString, out giataId);

                            newGiataHeaderInformationDataRow["GiataId"] = giataId;
                            //Console.WriteLine($"{url} -> {hotelCompanyModel.Gdsid} : {hotelCompanyModel.Accommodationid} - {giataId}");

                            string giataLastUpdated = ((XmlElement)propertyXmlNode).GetAttribute("lastUpdate");

                            newGiataHeaderInformationDataRow["LastUpdatedString"] = giataLastUpdated;

                            string[] lastUpdatedParts = giataLastUpdated.Split('+');

                            DateTime dt = DateTime.Parse(lastUpdatedParts[0]);

                            TimeSpan offSet = TimeSpan.Parse(lastUpdatedParts[1]);

                            dt = dt.AddHours(offSet.Hours).AddMinutes(offSet.Minutes).AddSeconds(offSet.Seconds);

                            newGiataHeaderInformationDataRow["LastUpdated"] = dt;

                            XmlNode propertyNameXmlNode = propertyXmlNode.SelectSingleNode("descendant::name");

                            if (propertyNameXmlNode != null)
                            {
                                newGiataHeaderInformationDataRow["GiataName"] = propertyNameXmlNode.InnerText;
                                //giataResponse.Name = propertyNameXmlNode.InnerText;
                            }

                            XmlNode cityXmlNode = propertyXmlNode.SelectSingleNode("descendant::city");

                            if (cityXmlNode != null)
                            {
                                int cityId = 0;

                                Int32.TryParse(((XmlElement)cityXmlNode).GetAttribute("cityId"), out cityId);

                                newGiataHeaderInformationDataRow["GiataCityId"] = cityId;

                                //giataResponse.CityId = cityId;

                                newGiataHeaderInformationDataRow["GiataCity"] = cityXmlNode.InnerText;

                                //giataResponse.City = cityXmlNode.InnerText;
                            }

                            XmlNode countryXmlNode = propertyXmlNode.SelectSingleNode("descendant::country");

                            if (countryXmlNode != null)
                            {
                                newGiataHeaderInformationDataRow["GiataCountry"] = countryXmlNode.InnerText;
                                //giataResponse.Country = countryXmlNode.InnerText;
                            }

                            XmlNodeList addressXmlNodeList = propertyXmlNode.SelectNodes("descendant::addresses");

                            if (addressXmlNodeList != null && addressXmlNodeList.Count > 0)
                            {
                                foreach (XmlNode addressXmlNode in addressXmlNodeList)
                                {
                                    XmlNodeList addressLineXmlNodeList =
                                        addressXmlNode.SelectNodes("descendant::addressLine");

                                    if (addressLineXmlNodeList != null)
                                    {
                                        foreach (XmlNode addressLineXmlNode in addressLineXmlNodeList)
                                        {
                                            string addressLineNumber =
                                                ((XmlElement)addressLineXmlNode).GetAttribute("addressLineNumber");

                                            if (addressLineNumber.Equals("1"))
                                            {
                                                newGiataHeaderInformationDataRow["GiataAddressLine1"] = addressLineXmlNode.InnerText;
                                                //giataAddress.AddressLineOne = addressLineXmlNode.InnerText;
                                            }
                                            else if (addressLineNumber.Equals("2"))
                                            {
                                                newGiataHeaderInformationDataRow["GiataAddressLine2"] = addressLineXmlNode.InnerText;
                                                //giataAddress.AddressLineTwo = addressLineXmlNode.InnerText;
                                            }
                                            else if (addressLineNumber.Equals("3"))
                                            {
                                                newGiataHeaderInformationDataRow["GiataAddressLine3"] = addressLineXmlNode.InnerText;
                                                //giataAddress.AddressLineThree = addressLineXmlNode.InnerText;
                                            }
                                            else if (addressLineNumber.Equals("4"))
                                            {
                                                newGiataHeaderInformationDataRow["GiataAddressLine4"] = addressLineXmlNode.InnerText;
                                                //giataAddress.AddressLineFour = addressLineXmlNode.InnerText;
                                            }
                                        }
                                    }



                                    XmlNode streetXmlNode = addressXmlNode.SelectSingleNode("descendant::street");

                                    if (streetXmlNode != null)
                                    {
                                        newGiataHeaderInformationDataRow["GiataStreet"] = streetXmlNode.InnerText;
                                        //giataAddress.Street = streetXmlNode.InnerText;
                                    }

                                    XmlNode streetNumberXmlNode = addressXmlNode.SelectSingleNode("descendant::streetNumber");

                                    if (streetNumberXmlNode != null)
                                    {
                                        newGiataHeaderInformationDataRow["GiataStreetNumber"] = streetNumberXmlNode.InnerText;
                                        //giataAddress.StreetNumber = streetNumberXmlNode.InnerText;
                                    }

                                    XmlNode cityNameXmlNode = addressXmlNode.SelectSingleNode("descendant::cityName");

                                    if (cityNameXmlNode != null)
                                    {
                                        newGiataHeaderInformationDataRow["GiataCityName"] = cityNameXmlNode.InnerText;
                                        //giataAddress.CityName = cityNameXmlNode.InnerText;
                                    }

                                    XmlNode postalCodeXmlNode = addressXmlNode.SelectSingleNode("descendant::postalCode");

                                    if (postalCodeXmlNode != null)
                                    {
                                        newGiataHeaderInformationDataRow["GiataPostalCode"] = postalCodeXmlNode.InnerText;
                                        //giataAddress.PoBox = postalCodeXmlNode.InnerText;
                                    }

                                    XmlNode addressCountryXmlNode = addressXmlNode.SelectSingleNode("descendant::country");

                                    if (addressCountryXmlNode != null)
                                    {
                                        newGiataHeaderInformationDataRow["GiataAddressCountry"] = addressCountryXmlNode.InnerText;
                                        //giataAddress.Country = addressCountryXmlNode.InnerText;
                                    }
                                }
                            }

                            XmlNode latitudeXmlNode =
                                propertyXmlNode.SelectSingleNode("descendant::geoCodes/geoCode/latitude");

                            if (latitudeXmlNode != null)
                            {
                                newGiataHeaderInformationDataRow["GiataLatitude"] = latitudeXmlNode.InnerText;
                                //giataResponse.Latitude = latitudeXmlNode.InnerText;
                            }

                            XmlNode longitudeXmlNode =
                                propertyXmlNode.SelectSingleNode("descendant::geoCodes/geoCode/longitude");

                            if (longitudeXmlNode != null)
                            {
                                newGiataHeaderInformationDataRow["GiataLongitude"] = longitudeXmlNode.InnerText;
                                //giataResponse.Longitude = longitudeXmlNode.InnerText;
                            }

                            XmlNodeList providerCodeXmlNodeList =
                                propertyXmlNode.SelectNodes("descendant::propertyCodes/provider");

                            if (providerCodeXmlNodeList != null)
                            {
                                foreach (XmlNode providerCodeXmlNode in providerCodeXmlNodeList)
                                {
                                    string providerCode =
                                            ((XmlElement)providerCodeXmlNode).GetAttribute("providerCode");

                                    string providerType =
                                        ((XmlElement)providerCodeXmlNode).GetAttribute("providerType");


                                    XmlNodeList codeXmlNodeList = providerCodeXmlNode.SelectNodes("descendant::code");

                                    if (codeXmlNodeList != null)
                                    {
                                        foreach (XmlNode codeXmlNode in codeXmlNodeList)
                                        {

                                            DataRow newGiataProviderInformationDataRow =
                                                giataProviderInformationDataTable.NewRow();

                                            XmlNode valueXmlNode = codeXmlNode.SelectSingleNode("descendant::value");

                                            if (valueXmlNode != null)
                                            {
                                                newGiataProviderInformationDataRow["ProviderCode"] = providerCode;
                                                newGiataProviderInformationDataRow["ProviderType"] = providerType;
                                                if (_gdsIdToGiataProviderCode.ContainsValue(providerCode))
                                                {
                                                    newGiataProviderInformationDataRow["GdsId"] = _gdsIdToGiataProviderCode.FirstOrDefault(
                                                        x => x.Value.ToLower().Equals(providerCode)).Key;

                                                    newGiataProviderInformationDataRow["GdsName"] =
                                                        gdsIdToGdsName[
                                                            Int32.Parse(
                                                                newGiataProviderInformationDataRow["GdsId"].ToString())];
                                                }
                                                newGiataProviderInformationDataRow["MasterHotelId"] =
                                                    hotelCompanyModel.MasterhotelId;
                                                newGiataProviderInformationDataRow["GiataId"] = giataId;
                                                newGiataProviderInformationDataRow["Value"] = valueXmlNode.InnerText;
                                                newGiataProviderInformationDataRow["CreatedDate"] = DateTime.Now;
                                            }
                                            giataProviderInformationDataTable.Rows.Add(newGiataProviderInformationDataRow);
                                        }
                                    }
                                }
                            }


                        }
                    }
                    recordCount++;
                    giataHeaderInformationDataTable.Rows.Add(newGiataHeaderInformationDataRow);

                    if (recordCount % numberOfRecordsTobeInsertedIntoDbInBulk == 0 || (hotelCompanyModels.Count - recordCount < numberOfRecordsTobeInsertedIntoDbInBulk && hotelCompanyModels.Count - 1 == recordCount))
                    {
                        Console.WriteLine($"Thread#: {numberOfThread} has processed {recordCount} records at {DateTime.Now:G}.");

                        DataTable giataHeaderToBeInserted = giataHeaderInformationDataTable.Copy();
                        DataTable giataProviderToBeInserted = giataProviderInformationDataTable.Copy();

                        giataHeaderInformationDataTable.Rows.Clear();
                        giataProviderInformationDataTable.Rows.Clear();

                        BulkInsertIntoDb(giataHeaderToBeInserted, giataProviderToBeInserted, numberOfThread);
                    }
                }

                Console.WriteLine("-----------------------------------------------------------------------");
                Console.WriteLine($"Thread#: {numberOfThread} Downloading and insertion of data completed.");
                Console.WriteLine("------------------------------------------------------------------------");

            }
            catch (Exception exception)
            {
                Console.WriteLine($"Thread#: {numberOfThread} exception is: {exception.Message}");
                throw new ApplicationException(exception.Message, exception.InnerException);
            }
        }

        private static void BulkInsertIntoDb(DataTable giataHeaderInformationDataTable,
            DataTable giataProviderInformationDataTable, int numberOfThread)
        {


            using (SqlConnection sqlConnection = new SqlConnection(ConfigurationManager.ConnectionStrings["SupplierDatabaseConnectionString"].ConnectionString))
            {
                sqlConnection.Open();

                try
                {
                    using (SqlBulkCopy sqlBulkCopy = new SqlBulkCopy(sqlConnection))
                    {
                        sqlBulkCopy.DestinationTableName = ConfigurationManager.AppSettings["GiataHeaderInformationTable"];

                        DbDataReader dbDataReader = new DataTableReader(giataHeaderInformationDataTable);

                        sqlBulkCopy.WriteToServer(dbDataReader);
                    }
                }
                catch (Exception exception)
                {
                    Console.WriteLine($"Exception has occured while inserting into GiataHeaderInformation. Exception Message: {exception.Message}");
                }

                try
                {
                    using (SqlBulkCopy sqlBulkCopy = new SqlBulkCopy(sqlConnection))
                    {
                        sqlBulkCopy.DestinationTableName = ConfigurationManager.AppSettings["GiataProviderInformationTable"];

                        DbDataReader dbDataReader = new DataTableReader(giataProviderInformationDataTable);

                        sqlBulkCopy.WriteToServer(dbDataReader);
                    }
                }
                catch (Exception exception)
                {
                    Console.WriteLine($"Exception has occured while inserting into GiataProviderInformation. Exception Message: {exception.Message}");
                }
            }
            if (giataHeaderInformationDataTable.Rows.Count != 100)
            {
                Console.WriteLine(
                    $"Thread# {numberOfThread} insertion into {ConfigurationManager.AppSettings["GiataHeaderInformationTable"]} completed for {giataHeaderInformationDataTable.Rows.Count} records in Header Information.");
            }
        }


        private static DataTable CreateGiataHeaderInformationDataTable()
        {
            DataTable giataHeaderDataTable = new DataTable();

            //giataHeaderDataTable.Columns.Add("Serial", typeof(Int32));
            giataHeaderDataTable.Columns.Add("HotelStaticId", typeof(Int32));
            giataHeaderDataTable.Columns.Add("MasterHotelId", typeof(Int32));
            giataHeaderDataTable.Columns.Add("CorrectedMasterHotelId", typeof(Int32));
            giataHeaderDataTable.Columns.Add("GdsId", typeof(Int32));
            giataHeaderDataTable.Columns.Add("GiataProviderCode", typeof(string));
            giataHeaderDataTable.Columns.Add("AccommodationId", typeof(string));
            giataHeaderDataTable.Columns.Add("GiataId", typeof(Int32));
            giataHeaderDataTable.Columns.Add("CorrectedGiataId", typeof(Int32));
            giataHeaderDataTable.Columns.Add("CorrectedRegionId", typeof(Int32));
            giataHeaderDataTable.Columns.Add("GateWayCode", typeof(string));
            giataHeaderDataTable.Columns.Add("DestinationCode", typeof(string));

            giataHeaderDataTable.Columns.Add("MasterHotelName", typeof(string));
            giataHeaderDataTable.Columns.Add("SupplierHotelName", typeof(string));
            giataHeaderDataTable.Columns.Add("MasterResortName", typeof(string));
            giataHeaderDataTable.Columns.Add("MasterCountryName", typeof(string));
            giataHeaderDataTable.Columns.Add("MasterCountryCode", typeof(string));
            giataHeaderDataTable.Columns.Add("MasterDestinationCode", typeof(string));
            giataHeaderDataTable.Columns.Add("MasterGiataCode", typeof(int));
            giataHeaderDataTable.Columns.Add("MasterLatitude", typeof(string));
            giataHeaderDataTable.Columns.Add("MasterLongitude", typeof(string));
            giataHeaderDataTable.Columns.Add("MasterCityTown", typeof(string));
            giataHeaderDataTable.Columns.Add("MasterAddressLine1", typeof(string));

            giataHeaderDataTable.Columns.Add("LastUpdatedString", typeof(string));
            giataHeaderDataTable.Columns.Add("LastUpdated", typeof(DateTime));
            giataHeaderDataTable.Columns.Add("GiataName", typeof(string));
            giataHeaderDataTable.Columns.Add("GiataCityId", typeof(Int32));
            giataHeaderDataTable.Columns.Add("GiataCity", typeof(string));
            giataHeaderDataTable.Columns.Add("GiataCountry", typeof(string));
            giataHeaderDataTable.Columns.Add("GiataAddressLine1", typeof(string));
            giataHeaderDataTable.Columns.Add("GiataAddressLine2", typeof(string));
            giataHeaderDataTable.Columns.Add("GiataAddressLine3", typeof(string));
            giataHeaderDataTable.Columns.Add("GiataAddressLine4", typeof(string));
            giataHeaderDataTable.Columns.Add("GiataStreet", typeof(string));
            giataHeaderDataTable.Columns.Add("GiataStreetNumber", typeof(string));
            giataHeaderDataTable.Columns.Add("GiataCityName", typeof(string));
            giataHeaderDataTable.Columns.Add("GiataPostalCode", typeof(string));
            giataHeaderDataTable.Columns.Add("GiataAddressCountry", typeof(string));
            giataHeaderDataTable.Columns.Add("GiataLatitude", typeof(string));
            giataHeaderDataTable.Columns.Add("GiataLongitude", typeof(string));
            giataHeaderDataTable.Columns.Add("CreatedDate", typeof(DateTime));
            giataHeaderDataTable.Columns.Add("ExceptionMessage", typeof(string));

            return giataHeaderDataTable;
        }

        private static DataTable CreateGiataProviderInformationHeaderTable()
        {
            DataTable giataProviderDataTable = new DataTable();

            giataProviderDataTable.Columns.Add("MasterHotelId", typeof(Int32));
            giataProviderDataTable.Columns.Add("CorrectedMasterHotelId", typeof(Int32));
            giataProviderDataTable.Columns.Add("GiataId", typeof(Int32));
            giataProviderDataTable.Columns.Add("CorrectedGiataId", typeof(Int32));
            giataProviderDataTable.Columns.Add("CorrectedRegionId", typeof(Int32));
            giataProviderDataTable.Columns.Add("CorrectedGdsId", typeof(Int32));
            giataProviderDataTable.Columns.Add("GdsId", typeof(Int32));
            giataProviderDataTable.Columns.Add("CorrectedSupplierHotelId", typeof(string));
            giataProviderDataTable.Columns.Add("GdsName", typeof(string));
            giataProviderDataTable.Columns.Add("CreatedDate", typeof(DateTime));
            giataProviderDataTable.Columns.Add("GdsCode", typeof(string));
            giataProviderDataTable.Columns.Add("ProviderCode", typeof(string));
            giataProviderDataTable.Columns.Add("ProviderType", typeof(string));
            giataProviderDataTable.Columns.Add("Value", typeof(string));

            return giataProviderDataTable;
        }

        
        private static List<HotelCompanyModel> GetHotelCompanyModelList()
        {
            List<HotelCompanyModel> hotelCompanyModels = new List<HotelCompanyModel>();

            using (SqlConnection sqlConnection = new SqlConnection(ConfigurationManager.ConnectionStrings["SupplierDatabaseConnectionString"].ConnectionString))
            {
                sqlConnection.Open();

                SqlCommand sqlSelectCommand = new SqlCommand(ConfigurationManager.AppSettings["GetHotelList"], sqlConnection)
                {
                    CommandType = CommandType.StoredProcedure
                };

                int insertRemainingItemsParams = 0;
                Int32.TryParse(ConfigurationManager.AppSettings["InsertRemainingItemsParameter"], out insertRemainingItemsParams);

                SqlParameter sqlParameter = new SqlParameter("@InsertRemainingItems", SqlDbType.Int)
                {
                    Value = insertRemainingItemsParams
                };

                sqlSelectCommand.Parameters.Add(sqlParameter);

                SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(sqlSelectCommand);

                DataSet resultDataSet = new DataSet();

                sqlDataAdapter.Fill(resultDataSet);

                if (resultDataSet.Tables.Count > 2)
                {
                    foreach (DataRow row in resultDataSet.Tables[0].Rows)
                    {
                        HotelCompanyModel hotelCompanyModel = new HotelCompanyModel();

                        hotelCompanyModel.GdsName = row["Gdsname"] != DBNull.Value
                            ? row["Gdsname"].ToString()
                            : String.Empty;

                        hotelCompanyModel.GdsId = row["GDSID"] != DBNull.Value
                            ? Int32.Parse(row["GDSID"].ToString())
                            : Int32.MinValue;

                        hotelCompanyModel.AccommodationId = row["Accommodationid"] != DBNull.Value
                            ? row["Accommodationid"].ToString()
                            : String.Empty;

                        hotelCompanyModel.MasterhotelId = row["Masterhotelid"] != DBNull.Value
                            ? Int32.Parse(row["Masterhotelid"].ToString())
                            : -1;

                        hotelCompanyModel.MasterGiataCode = row["MasterGiataCode"] != DBNull.Value
                            ? Int32.Parse(row["MasterGiataCode"].ToString())
                            : Int32.MinValue;

                        hotelCompanyModel.HotelStaticId = row["HotelStaticId"] != DBNull.Value
                            ? Int32.Parse(row["HotelStaticId"].ToString())
                            : Int32.MinValue;

                        hotelCompanyModel.MasterHotelName = row["MasterHotelName"] != DBNull.Value
                            ? row["MasterHotelName"].ToString()
                            : String.Empty;

                        hotelCompanyModel.MasterResortName = row["MasterResortName"] != DBNull.Value
                            ? row["MasterResortName"].ToString()
                            : String.Empty;

                        hotelCompanyModel.CountryName = row["CountryName"] != DBNull.Value
                            ? row["CountryName"].ToString()
                            : String.Empty;

                        hotelCompanyModel.GatewayCode = row["GatewayCode"] != DBNull.Value
                            ? row["GatewayCode"].ToString()
                            : String.Empty;

                        hotelCompanyModel.DestinationCode = row["DestinationCode"] != DBNull.Value
                            ? row["DestinationCode"].ToString()
                            : String.Empty;

                        hotelCompanyModel.MasterGiataCode = row["MasterGiataCode"] != DBNull.Value
                            ? Int32.Parse(row["MasterGiataCode"].ToString())
                            : 0;

                        hotelCompanyModel.Latitude = row["Latitude"] != DBNull.Value
                            ? row["Latitude"].ToString()
                            : String.Empty;

                        hotelCompanyModel.Longitude = row["Longitude"] != DBNull.Value
                            ? row["Longitude"].ToString()
                            : String.Empty;

                        hotelCompanyModel.CityTown = row["CityTown"] != DBNull.Value
                            ? row["CityTown"].ToString()
                            : String.Empty;

                        hotelCompanyModel.Addressline1 = row["Addressline1"] != DBNull.Value
                            ? row["Addressline1"].ToString()
                            : String.Empty;

                        hotelCompanyModel.SupplierHotelName = row["SupplierHotelName"] != DBNull.Value
                            ? row["SupplierHotelName"].ToString()
                            : String.Empty;

                        hotelCompanyModels.Add(hotelCompanyModel);
                    }

                    foreach (DataRow row in resultDataSet.Tables[1].Rows)
                    {
                        int gdsId = row["GdsId"] != DBNull.Value ? Int32.Parse(row["GdsId"].ToString()) : Int32.MinValue;

                        if (!_gdsIdToGiataProviderCode.ContainsKey(gdsId))
                        {
                            _gdsIdToGiataProviderCode.Add(gdsId, row["GiataProviderCode"].ToString());
                        }
                        else
                        {
                            Console.WriteLine($"{gdsId} is already present in the dictionary.");
                        }
                    }

                    foreach (DataRow dataRow in resultDataSet.Tables[2].Rows)
                    {
                        int gdsId = dataRow["GdsId"] != DBNull.Value
                            ? Int32.Parse(dataRow["GdsId"].ToString())
                            : Int32.MinValue;

                        if (!gdsIdToGdsName.ContainsKey(gdsId))
                        {
                            gdsIdToGdsName.Add(gdsId, dataRow["GdsName"].ToString());
                        }
                        else
                        {
                            Console.WriteLine($"{gdsId} is already present in the gdsIdToGdsName dictionary.");
                        }
                    }

                }
            }

            return hotelCompanyModels;
        }
    }
}
