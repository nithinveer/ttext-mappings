﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using DownloadGiataIdForTtssExportedRecords.Model;

namespace DownloadGiataIdForTtssExportedRecords
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                List<TtssExportedModel> ttssExportedModels = GetTtssExportedModels();

                int numberOfItemsPerThread = 0;
                Int32.TryParse(ConfigurationManager.AppSettings["NumberOfItemsPerThread"], out numberOfItemsPerThread);

                int quotient = 0;
                int numberOfThreads = Math.DivRem(ttssExportedModels.Count, numberOfItemsPerThread, out quotient);

                numberOfThreads = quotient == 0 ? numberOfThreads : numberOfThreads + 1;

                List<Task> tasksCreated = new List<Task>();

                for (int loopIndex = 0; loopIndex < numberOfThreads; loopIndex++)
                {
                    List<TtssExportedModel> recordsToBeProcessed = ttssExportedModels.Skip(loopIndex * numberOfItemsPerThread).Take(numberOfItemsPerThread).ToList();

                    int threadIndex = loopIndex;

                    tasksCreated.Add(Task.Factory.StartNew(() =>
                    {
                        DownloadGiataHeaderInformationAndInsertIntoDb(recordsToBeProcessed, threadIndex);
                    }));
                }

                while (tasksCreated.Count > 0)
                {
                    int taskIndex = Task.WaitAny(tasksCreated.ToArray());

                    if (tasksCreated[taskIndex].Exception == null)
                    {
                        Console.WriteLine($"TaskIndex#: {taskIndex} has been completed.");
                    }
                    else
                    {
                        foreach (Exception exception in tasksCreated[taskIndex].Exception.InnerExceptions)
                        {
                            Console.WriteLine($"TaskIndex#: {taskIndex} has failed with the following exception. Message: {exception.Message}");
                        }

                    }
                    tasksCreated.RemoveAt(taskIndex);
                }

                if (tasksCreated.Count == 0)
                {
                    Console.WriteLine("===============================================");
                    Console.WriteLine($"Downloading and insertion into db completed.");
                    Console.WriteLine("===============================================");
                }
            }
            catch (Exception exception)
            {
                Console.WriteLine($"Exception occured in Main.\nMessage: {exception.Message}.\nStack Trace: {exception.StackTrace}");
                throw;
            }

            Console.ReadLine();
        }

        private static void DownloadGiataHeaderInformationAndInsertIntoDb(List<TtssExportedModel> ttssExportedModels,
            int numberOfThread)
        {
            try
            {
                Console.WriteLine(
                        $"{numberOfThread} First MHId: {ttssExportedModels[0].MasterHotelId}. Last MasterHotelId: {ttssExportedModels[ttssExportedModels.Count - 1].MasterHotelId}. Size: {ttssExportedModels.Count}");

                DataTable giataHeaderInformationDataTable = CreateGiataHeaderInformationDataTable();

                int recordCount = 0;

                int numberOfRecordsTobeInsertedIntoDbInBulk = 0;
                Int32.TryParse(ConfigurationManager.AppSettings["NumberOfRecordsToBeInsertedInBulk"],
                    out numberOfRecordsTobeInsertedIntoDbInBulk);

                foreach (TtssExportedModel ttssExportedModel in ttssExportedModels)
                {
                    DataRow newGiataHeaderInformationDataRow = giataHeaderInformationDataTable.NewRow();

                    //newGiataHeaderInformationDataRow["Serial"] = hotelCompanyModel.Serial;
                    newGiataHeaderInformationDataRow["MasterHotelId"] = ttssExportedModel.MasterHotelId;
                    newGiataHeaderInformationDataRow["MasterHotelName"] = ttssExportedModel.MasterHotelName;
                    newGiataHeaderInformationDataRow["GdsId"] = ttssExportedModel.GdsId;
                    newGiataHeaderInformationDataRow["GdsName"] = ttssExportedModel.GdsName;
                    newGiataHeaderInformationDataRow["GiataProviderCode"] = ttssExportedModel.GiataProviderCode;
                    newGiataHeaderInformationDataRow["AccommodationId"] = ttssExportedModel.AccommodationId;
                    newGiataHeaderInformationDataRow["CreatedDate"] = DateTime.Now;

                    if (String.IsNullOrEmpty(ttssExportedModel.GiataProviderCode) ||
                        String.IsNullOrWhiteSpace(ttssExportedModel.GiataProviderCode))
                    {
                        newGiataHeaderInformationDataRow["GiataId"] = -2;
                        recordCount++;
                        giataHeaderInformationDataTable.Rows.Add(newGiataHeaderInformationDataRow);

                        if (recordCount % numberOfRecordsTobeInsertedIntoDbInBulk == 0)
                        {

                            Console.WriteLine($"Thread#: {numberOfThread} has processed {recordCount} records at {DateTime.Now:G}.");

                            DataTable giataHeaderToBeInserted = giataHeaderInformationDataTable.Copy();

                            giataHeaderInformationDataTable.Rows.Clear();

                            BulkInsertGiataHeaderInformationIntoDb(giataHeaderToBeInserted, numberOfThread);
                        }
                        continue;
                    }

                    string giataUrl = ConfigurationManager.AppSettings["GiataUrl"];
                    string url = String.Empty;

                    if (ttssExportedModel.GdsId == 19)
                    {
                        url = String.Format(giataUrl, ttssExportedModel.GiataProviderCode,
                            "LCB|" + ttssExportedModel.AccommodationId);
                    }
                    else if (ttssExportedModel.GdsId == 10)
                    {
                        url = String.Format(giataUrl, ttssExportedModel.GiataProviderCode,
                            ttssExportedModel.GdsName + "|" + ttssExportedModel.AccommodationId);
                    }
                    else if (ttssExportedModel.GdsId == 35)
                    {
                        if (ttssExportedModel.AccommodationId.ToLower().IndexOf("hbe|", StringComparison.Ordinal) == -1)
                        {
                            url = String.Format(giataUrl, ttssExportedModel.GiataProviderCode,
                                ttssExportedModel.AccommodationId);
                        }
                        else if (ttssExportedModel.AccommodationId.ToLower().IndexOf("hbe|") > -1)
                        {
                            url = String.Format(giataUrl, ttssExportedModel.GiataProviderCode,
                                ttssExportedModel.AccommodationId.Split('|')[1]);
                        }
                    }
                    else if (ttssExportedModel.GdsId != 10)
                    {
                        url = String.Format(giataUrl, ttssExportedModel.GiataProviderCode,
                            ttssExportedModel.AccommodationId);
                    }

                    //Console.WriteLine($"Url is: {url}");

                    Stream giataOutputStream = null;

                    try
                    {
                        HttpWebRequest httpWebRequest = (HttpWebRequest)WebRequest.Create(url);
                        httpWebRequest.Proxy = null;
                        httpWebRequest.Method = WebRequestMethods.Http.Get;
                        httpWebRequest.Credentials = new NetworkCredential(
                            ConfigurationManager.AppSettings["GiataUserName"],
                            ConfigurationManager.AppSettings["GiataPassword"]);
                        httpWebRequest.AllowAutoRedirect = false;
                        HttpWebResponse response = (HttpWebResponse)httpWebRequest.GetResponse();

                        giataOutputStream = response.GetResponseStream();
                    }
                    catch (Exception exception)
                    {
                        newGiataHeaderInformationDataRow["ExceptionMessage"] =
                            $"Thread# {numberOfThread} -> Url is: {url}. Failed for {ttssExportedModel.MasterHotelId} and exception is: {exception.Message}";

                        Console.WriteLine($"Thread# {numberOfThread} -> Failed Url is: {url}");
                    }

                    if (giataOutputStream == null)
                    {
                        newGiataHeaderInformationDataRow["GiataId"] = -1;
                        newGiataHeaderInformationDataRow["ExceptionMessage"] =
                            $"Thread# {numberOfThread} -> Url is: {url}. Failed for {ttssExportedModel.MasterHotelId}";
                    }
                    else if (giataOutputStream != null)
                    {
                        XmlDocument giataXmlDocument = new XmlDocument();

                        giataXmlDocument.Load(giataOutputStream);

                        XmlNode propertyXmlNode = giataXmlDocument.SelectSingleNode("descendant::properties/property");

                        if (propertyXmlNode == null)
                        {
                            XmlNode codeXmlNode = giataXmlDocument.SelectSingleNode("descendant::error/code");

                            if (codeXmlNode != null)
                            {

                                string errorCode = codeXmlNode.InnerText;

                                if (errorCode.Equals("301"))
                                {
                                    XmlNode descriptionXmlNode =
                                        giataXmlDocument.SelectSingleNode("descendant::error/description");

                                    string redirectUrl = ((XmlElement) descriptionXmlNode).GetAttribute("xlink:href");

                                    string[] redirectUrlParts = redirectUrl.Split('/');

                                    string newGiataIdString = redirectUrlParts[redirectUrlParts.Length - 1];

                                    int newGiataId = 0;
                                    Int32.TryParse(newGiataIdString, out newGiataId);

                                    newGiataHeaderInformationDataRow["NewGiataId"] = newGiataId;
                                }
                            }
                            else if (codeXmlNode == null)
                            {
                                newGiataHeaderInformationDataRow["GiataId"] = 0;
                            }
                        }
                        else if (propertyXmlNode != null)
                        {
                            string giataIdString = ((XmlElement)propertyXmlNode).GetAttribute("giataId");
                            int giataId = 0;

                            Int32.TryParse(giataIdString, out giataId);

                            newGiataHeaderInformationDataRow["GiataId"] = giataId;
                            //Console.WriteLine($"{url} -> {hotelCompanyModel.Gdsid} : {hotelCompanyModel.Accommodationid} - {giataId}");

                            string giataLastUpdated = ((XmlElement)propertyXmlNode).GetAttribute("lastUpdate");

                            newGiataHeaderInformationDataRow["LastUpdatedString"] = giataLastUpdated;

                            string[] lastUpdatedParts = giataLastUpdated.Split('+');

                            DateTime dt = DateTime.Parse(lastUpdatedParts[0]);

                            TimeSpan offSet = TimeSpan.Parse(lastUpdatedParts[1]);

                            dt = dt.AddHours(offSet.Hours).AddMinutes(offSet.Minutes).AddSeconds(offSet.Seconds);

                            newGiataHeaderInformationDataRow["LastUpdated"] = dt;

                            XmlNode propertyNameXmlNode = propertyXmlNode.SelectSingleNode("descendant::name");

                            if (propertyNameXmlNode != null)
                            {
                                newGiataHeaderInformationDataRow["GiataName"] = propertyNameXmlNode.InnerText;
                                //giataResponse.Name = propertyNameXmlNode.InnerText;
                            }

                            XmlNode cityXmlNode = propertyXmlNode.SelectSingleNode("descendant::city");

                            if (cityXmlNode != null)
                            {
                                int cityId = 0;

                                Int32.TryParse(((XmlElement)cityXmlNode).GetAttribute("cityId"), out cityId);

                                newGiataHeaderInformationDataRow["GiataCityId"] = cityId;

                                //giataResponse.CityId = cityId;

                                newGiataHeaderInformationDataRow["GiataCity"] = cityXmlNode.InnerText;

                                //giataResponse.City = cityXmlNode.InnerText;
                            }

                            XmlNode countryXmlNode = propertyXmlNode.SelectSingleNode("descendant::country");

                            if (countryXmlNode != null)
                            {
                                newGiataHeaderInformationDataRow["GiataCountry"] = countryXmlNode.InnerText;
                                //giataResponse.Country = countryXmlNode.InnerText;
                            }

                            XmlNodeList addressXmlNodeList = propertyXmlNode.SelectNodes("descendant::addresses");

                            if (addressXmlNodeList != null && addressXmlNodeList.Count > 0)
                            {
                                foreach (XmlNode addressXmlNode in addressXmlNodeList)
                                {
                                    XmlNodeList addressLineXmlNodeList =
                                        addressXmlNode.SelectNodes("descendant::addressLine");

                                    if (addressLineXmlNodeList != null)
                                    {
                                        foreach (XmlNode addressLineXmlNode in addressLineXmlNodeList)
                                        {
                                            string addressLineNumber =
                                                ((XmlElement)addressLineXmlNode).GetAttribute("addressLineNumber");

                                            if (addressLineNumber.Equals("1"))
                                            {
                                                newGiataHeaderInformationDataRow["GiataAddressLine1"] =
                                                    addressLineXmlNode.InnerText;
                                                //giataAddress.AddressLineOne = addressLineXmlNode.InnerText;
                                            }
                                            else if (addressLineNumber.Equals("2"))
                                            {
                                                newGiataHeaderInformationDataRow["GiataAddressLine2"] =
                                                    addressLineXmlNode.InnerText;
                                                //giataAddress.AddressLineTwo = addressLineXmlNode.InnerText;
                                            }
                                            else if (addressLineNumber.Equals("3"))
                                            {
                                                newGiataHeaderInformationDataRow["GiataAddressLine3"] =
                                                    addressLineXmlNode.InnerText;
                                                //giataAddress.AddressLineThree = addressLineXmlNode.InnerText;
                                            }
                                            else if (addressLineNumber.Equals("4"))
                                            {
                                                newGiataHeaderInformationDataRow["GiataAddressLine4"] =
                                                    addressLineXmlNode.InnerText;
                                                //giataAddress.AddressLineFour = addressLineXmlNode.InnerText;
                                            }
                                        }
                                    }



                                    XmlNode streetXmlNode = addressXmlNode.SelectSingleNode("descendant::street");

                                    if (streetXmlNode != null)
                                    {
                                        newGiataHeaderInformationDataRow["GiataStreet"] = streetXmlNode.InnerText;
                                        //giataAddress.Street = streetXmlNode.InnerText;
                                    }

                                    XmlNode streetNumberXmlNode = addressXmlNode.SelectSingleNode("descendant::streetNumber");

                                    if (streetNumberXmlNode != null)
                                    {
                                        newGiataHeaderInformationDataRow["GiataStreetNumber"] =
                                            streetNumberXmlNode.InnerText;
                                        //giataAddress.StreetNumber = streetNumberXmlNode.InnerText;
                                    }

                                    XmlNode cityNameXmlNode = addressXmlNode.SelectSingleNode("descendant::cityName");

                                    if (cityNameXmlNode != null)
                                    {
                                        newGiataHeaderInformationDataRow["GiataCityName"] = cityNameXmlNode.InnerText;
                                        //giataAddress.CityName = cityNameXmlNode.InnerText;
                                    }

                                    XmlNode postalCodeXmlNode = addressXmlNode.SelectSingleNode("descendant::postalCode");

                                    if (postalCodeXmlNode != null)
                                    {
                                        newGiataHeaderInformationDataRow["GiataPostalCode"] = postalCodeXmlNode.InnerText;
                                        //giataAddress.PoBox = postalCodeXmlNode.InnerText;
                                    }

                                    XmlNode addressCountryXmlNode = addressXmlNode.SelectSingleNode("descendant::country");

                                    if (addressCountryXmlNode != null)
                                    {
                                        newGiataHeaderInformationDataRow["GiataAddressCountry"] =
                                            addressCountryXmlNode.InnerText;
                                        //giataAddress.Country = addressCountryXmlNode.InnerText;
                                    }
                                }
                            }

                            XmlNode latitudeXmlNode =
                                propertyXmlNode.SelectSingleNode("descendant::geoCodes/geoCode/latitude");

                            if (latitudeXmlNode != null)
                            {
                                newGiataHeaderInformationDataRow["GiataLatitude"] = latitudeXmlNode.InnerText;
                                //giataResponse.Latitude = latitudeXmlNode.InnerText;
                            }

                            XmlNode longitudeXmlNode =
                                propertyXmlNode.SelectSingleNode("descendant::geoCodes/geoCode/longitude");

                            if (longitudeXmlNode != null)
                            {
                                newGiataHeaderInformationDataRow["GiataLongitude"] = longitudeXmlNode.InnerText;
                                //giataResponse.Longitude = longitudeXmlNode.InnerText;
                            }
                        }
                    }

                    recordCount++;
                    giataHeaderInformationDataTable.Rows.Add(newGiataHeaderInformationDataRow);

                    if (recordCount % numberOfRecordsTobeInsertedIntoDbInBulk == 0 || (ttssExportedModels.Count - recordCount < numberOfRecordsTobeInsertedIntoDbInBulk && ttssExportedModels.Count - 1 == recordCount))
                    {

                        Console.WriteLine($"Thread#: {numberOfThread} has processed {recordCount} records at {DateTime.Now:G}.");

                        DataTable giataHeaderToBeInserted = giataHeaderInformationDataTable.Copy();

                        giataHeaderInformationDataTable.Rows.Clear();

                        BulkInsertGiataHeaderInformationIntoDb(giataHeaderToBeInserted, numberOfThread);
                    }
                }
            }
            catch (Exception exception)
            {
                Console.WriteLine($"Thread#: {numberOfThread} exception has occured.\nException Message: {exception.Message}.\nStackTrace: {exception.StackTrace}");
                throw;
            }
        }

        private static void BulkInsertGiataHeaderInformationIntoDb(DataTable giataHeaderInformationToBeInserted,
            int numberOfThread)
        {
            try
            {
                using (
                    SqlConnection sqlConnection =
                        new SqlConnection(ConfigurationManager.ConnectionStrings["DbConnectionString"].ConnectionString))
                {
                    sqlConnection.Open();

                    using (SqlBulkCopy sqlBulkCopy = new SqlBulkCopy(sqlConnection))
                    {
                        sqlBulkCopy.DestinationTableName = ConfigurationManager.AppSettings["GiataHeaderInformationTable"];

                        DbDataReader dbDataReader = new DataTableReader(giataHeaderInformationToBeInserted);

                        sqlBulkCopy.WriteToServer(dbDataReader);
                    }
                }
            }
            catch (Exception exception)
            {
                Console.WriteLine($"Exception has occured while inserting into GiataHeaderInformation. Exception Message: {exception.Message}");
                throw;
            }
            if (giataHeaderInformationToBeInserted.Rows.Count != 100)
            {
                Console.WriteLine(
                    $"Thread# {numberOfThread} insertion into {ConfigurationManager.AppSettings["GiataHeaderInformationTable"]} completed for {giataHeaderInformationToBeInserted.Rows.Count} records in Header Information.");
            }
        }

        private static DataTable CreateGiataHeaderInformationDataTable()
        {
            DataTable giataHeaderDataTable = new DataTable();

            //giataHeaderDataTable.Columns.Add("Serial", typeof(Int32));
            giataHeaderDataTable.Columns.Add("MasterHotelName", typeof(string));
            giataHeaderDataTable.Columns.Add("MasterHotelId", typeof(Int32));
            giataHeaderDataTable.Columns.Add("GdsId", typeof(Int32));
            giataHeaderDataTable.Columns.Add("GdsName", typeof(string));
            giataHeaderDataTable.Columns.Add("GiataProviderCode", typeof(string));
            giataHeaderDataTable.Columns.Add("AccommodationId", typeof(string));
            giataHeaderDataTable.Columns.Add("GiataId", typeof(Int32));
            giataHeaderDataTable.Columns.Add("LastUpdatedString", typeof(string));
            giataHeaderDataTable.Columns.Add("LastUpdated", typeof(DateTime));
            giataHeaderDataTable.Columns.Add("GiataName", typeof(string));
            giataHeaderDataTable.Columns.Add("GiataCityId", typeof(Int32));
            giataHeaderDataTable.Columns.Add("GiataCity", typeof(string));
            giataHeaderDataTable.Columns.Add("GiataCountry", typeof(string));
            giataHeaderDataTable.Columns.Add("GiataAddressLine1", typeof(string));
            giataHeaderDataTable.Columns.Add("GiataAddressLine2", typeof(string));
            giataHeaderDataTable.Columns.Add("GiataAddressLine3", typeof(string));
            giataHeaderDataTable.Columns.Add("GiataAddressLine4", typeof(string));
            giataHeaderDataTable.Columns.Add("GiataStreet", typeof(string));
            giataHeaderDataTable.Columns.Add("GiataStreetNumber", typeof(string));
            giataHeaderDataTable.Columns.Add("GiataCityName", typeof(string));
            giataHeaderDataTable.Columns.Add("GiataPostalCode", typeof(string));
            giataHeaderDataTable.Columns.Add("GiataAddressCountry", typeof(string));
            giataHeaderDataTable.Columns.Add("GiataLatitude", typeof(string));
            giataHeaderDataTable.Columns.Add("GiataLongitude", typeof(string));
            giataHeaderDataTable.Columns.Add("CreatedDate", typeof(DateTime));
            giataHeaderDataTable.Columns.Add("ExceptionMessage", typeof(string));

            return giataHeaderDataTable;
        }

        private static List<TtssExportedModel> GetTtssExportedModels()
        {
            List<TtssExportedModel> ttssExportedModels = new List<TtssExportedModel>();

            try
            {
                using (
                    SqlConnection sqlConnection =
                        new SqlConnection(ConfigurationManager.ConnectionStrings["DbConnectionString"].ConnectionString))
                {
                    sqlConnection.Open();

                    SqlCommand sqlSelectCommand =
                        new SqlCommand(ConfigurationManager.AppSettings["RetrieveTtssExportListForGiataDownloadSP"], sqlConnection)
                        {
                            CommandType = CommandType.StoredProcedure
                        };

                    int insertRemainingParams = 0;
                    Int32.TryParse(ConfigurationManager.AppSettings["InsertRemainingParams"], out insertRemainingParams);

                    SqlParameter sqlParameter = new SqlParameter("@InsertRemainingParams", SqlDbType.Int)
                    {
                        Value = insertRemainingParams
                    };

                    sqlSelectCommand.Parameters.Add(sqlParameter);

                    SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(sqlSelectCommand);

                    DataSet resultDataSet = new DataSet();

                    sqlDataAdapter.Fill(resultDataSet);

                    if (resultDataSet.Tables.Count > 0)
                    {
                        if (resultDataSet.Tables[0].Rows.Count > 0)
                        {
                            foreach (DataRow dataRow in resultDataSet.Tables[0].Rows)
                            {
                                TtssExportedModel ttssExportedModel =
                                    new TtssExportedModel
                                    {
                                        GdsId =
                                            dataRow["GdsId"] != DBNull.Value
                                                ? Convert.ToInt32(dataRow["GdsId"])
                                                : -1,
                                        MasterHotelId =
                                            dataRow["MasterHotelId"] != DBNull.Value
                                                ? Convert.ToInt32(dataRow["MasterHotelId"])
                                                : -1,
                                        MasterHotelName =
                                            dataRow["MasterHotelName"] != DBNull.Value
                                                ? dataRow["MasterHotelName"].ToString()
                                                : String.Empty,
                                        AccommodationId = dataRow["AccommodationId"] != DBNull.Value ? dataRow["AccommodationId"].ToString() : String.Empty,
                                        GdsName = dataRow["GdsName"] != DBNull.Value ? dataRow["GdsName"].ToString() : String.Empty,
                                        GiataProviderCode = dataRow["GiataProviderCode"] != DBNull.Value ? dataRow["GiataProviderCode"].ToString() : String.Empty
                                    };


                                ttssExportedModels.Add(ttssExportedModel);
                            }
                        }
                    }
                }
            }
            catch (Exception exception)
            {
                Console.WriteLine($"Exception occured in GetTtssExportedModels.\nMessage: {exception.Message}.\nStack Trace: {exception.StackTrace}");
                throw;
            }

            return ttssExportedModels;
        }
    }
}
