﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DownloadGiataIdForTtssExportedRecords.Model
{
    public class TtssExportedModel
    {
        public int MasterHotelId { get; set; }
        public string MasterHotelName { get; set; }
        public int GdsId { get; set; }
        public string GdsName { get; set; }
        public string GiataProviderCode { get; set; }
        public string AccommodationId { get; set; }
    }
}
