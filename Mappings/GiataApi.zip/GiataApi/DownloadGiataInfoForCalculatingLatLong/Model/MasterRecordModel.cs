﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DownloadGiataInfoForCalculatingLatLong.Model
{
    public class MasterRecordModel
    {
        public int HotelStaticId { get; set; }
        public int MasterHotelId { get; set; }
        public int GdsId { get; set; }
        public string GiataProviderCode { get; set; }
        public string AccommodationId { get; set; }
        public string RecordSource { get; set; }
    }
}
