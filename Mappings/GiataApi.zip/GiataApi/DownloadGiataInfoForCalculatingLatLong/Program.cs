﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using DownloadGiataInfoForCalculatingLatLong.Model;

namespace DownloadGiataInfoForCalculatingLatLong
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                string latitudeLongitudeConnectionString = ConfigurationManager.ConnectionStrings["LatitudeAndLongitudeCalcualation_ConnectionString"].ConnectionString;

                if (String.IsNullOrEmpty(latitudeLongitudeConnectionString) ||
                    String.IsNullOrWhiteSpace(latitudeLongitudeConnectionString))
                {
                    Console.WriteLine($"LatitudeLongitude Connection String is null or empty or whitespace.");
                    return;
                }

                List<MasterRecordModel> masterRecordModels = GetMasterRecordModels(latitudeLongitudeConnectionString);

                int numberOfItemsPerThread = 0;
                Int32.TryParse(ConfigurationManager.AppSettings["NumberOfItemsPerThread"], out numberOfItemsPerThread);

                int quotient = 0;
                int numberOfThreads = Math.DivRem(masterRecordModels.Count, numberOfItemsPerThread, out quotient);

                numberOfThreads = quotient == 0 ? numberOfThreads : numberOfThreads + 1;

                List<Task> tasksCreated = new List<Task>();

                for (int loopIndex = 0; loopIndex < numberOfThreads; loopIndex++)
                {
                    List<MasterRecordModel> recordsToBeProcessed = masterRecordModels.Skip(loopIndex * numberOfItemsPerThread).Take(numberOfItemsPerThread).ToList();

                    int threadIndex = loopIndex;

                    tasksCreated.Add(Task.Factory.StartNew(() =>
                    {
                        DownloadGiataDataAndInsertIntoDb(recordsToBeProcessed, latitudeLongitudeConnectionString, threadIndex);
                    }));
                }

                while (tasksCreated.Count > 0)
                {
                    int taskIndex = Task.WaitAny(tasksCreated.ToArray());

                    if (tasksCreated[taskIndex].Exception == null)
                    {
                        Console.WriteLine($"TaskIndex#: {taskIndex} has been completed.");
                    }
                    else
                    {
                        foreach (Exception exception in tasksCreated[taskIndex].Exception.InnerExceptions)
                        {
                            Console.WriteLine($"TaskIndex#: {taskIndex} has failed with the following exception. Message: {exception.Message}");
                        }

                    }
                    tasksCreated.RemoveAt(taskIndex);
                }

                if (tasksCreated.Count == 0)
                {
                    Console.WriteLine();
                    Console.WriteLine("===============================================");
                    Console.WriteLine("===============================================");
                    Console.WriteLine($"Downloading and insertion into db completed.");
                    Console.WriteLine("===============================================");
                    Console.WriteLine("===============================================");
                }

                Console.ReadLine();
            }
            catch (Exception exception)
            {
                Console.Write($"Exception has occured in Main. Exception Message: {exception.Message}. StackTrace: {exception.StackTrace}");
            }
        }

        private static void DownloadGiataDataAndInsertIntoDb(List<MasterRecordModel> masterRecordModels, string latitudeLongitudeConnectionString, int numberOfThread)
        {
            List<string> status = new List<string>();
            try
            {
                //Console.WriteLine($"{numberOfThread} Task started at: {DateTime.Now.ToString("G")}");
                Console.WriteLine($"{numberOfThread} Fist MHId: {masterRecordModels[0].MasterHotelId}. Last MHId: {masterRecordModels[masterRecordModels.Count - 1].MasterHotelId}. Size: {masterRecordModels.Count}");

                DataTable giataHeaderInformationDataTable = CreateGiataHeaderInformationDataTable();

                DataTable giataProviderInformationDataTable = CreateGiataProviderInformationHeaderTable();

                int recordCount = 0;

                int numberOfRecordsTobeInsertedIntoDbInBulk = 0;
                Int32.TryParse(ConfigurationManager.AppSettings["NumberOfRecordsToBeInsertedInBulk"], out numberOfRecordsTobeInsertedIntoDbInBulk);

                foreach (MasterRecordModel masterRecordModel in masterRecordModels)
                {
                    DataRow newGiataHeaderInformationDataRow = giataHeaderInformationDataTable.NewRow();

                    newGiataHeaderInformationDataRow["HotelStaticId"] = masterRecordModel.HotelStaticId;
                    newGiataHeaderInformationDataRow["MasterHotelId"] = masterRecordModel.MasterHotelId;

                    newGiataHeaderInformationDataRow["GdsId"] = masterRecordModel.GdsId;
                    newGiataHeaderInformationDataRow["AccommodationId"] = masterRecordModel.AccommodationId;
                    newGiataHeaderInformationDataRow["CreatedDate"] = DateTime.Now;

                    newGiataHeaderInformationDataRow["GiataProviderCode"] = masterRecordModel.GiataProviderCode;

                    newGiataHeaderInformationDataRow["RecordSource"] = masterRecordModel.RecordSource;

                    if (String.IsNullOrEmpty(masterRecordModel.GiataProviderCode) ||
                        String.IsNullOrWhiteSpace(masterRecordModel.GiataProviderCode))
                    {
                        newGiataHeaderInformationDataRow["GiataId"] = -2;
                        recordCount++;
                        giataHeaderInformationDataTable.Rows.Add(newGiataHeaderInformationDataRow);

                        if (recordCount % numberOfRecordsTobeInsertedIntoDbInBulk == 0)
                        {

                            Console.WriteLine($"Thread#: {numberOfThread} has processed {recordCount} records.");

                            DataTable giataHeaderToBeInserted = giataHeaderInformationDataTable.Copy();
                            DataTable giataProviderToBeInserted = giataProviderInformationDataTable.Copy();

                            giataHeaderInformationDataTable.Rows.Clear();
                            giataProviderInformationDataTable.Rows.Clear();

                            BulkInsertIntoDb(giataHeaderToBeInserted, giataProviderToBeInserted, latitudeLongitudeConnectionString, numberOfThread);
                        }
                        continue;
                    }

                    string giataUrl = ConfigurationManager.AppSettings["GiataUrl"];
                    string url = String.Empty;

                    if (masterRecordModel.GdsId == 10)
                    {
                        url = String.Format(giataUrl, masterRecordModel.GiataProviderCode,
                            "H4U|" + masterRecordModel.AccommodationId);
                    }
                    else if (masterRecordModel.GdsId == 35)
                    {
                        url = String.Format(giataUrl, masterRecordModel.GiataProviderCode,
                            masterRecordModel.AccommodationId.Split('|')[1]);
                    }
                    else
                    {
                        url = String.Format(giataUrl, masterRecordModel.GiataProviderCode,
                            masterRecordModel.AccommodationId);
                    }

                    Stream giataOutputStream = null;

                    try
                    {
                        HttpWebRequest httpWebRequest = (HttpWebRequest)WebRequest.Create(url);
                        httpWebRequest.Proxy = null;
                        httpWebRequest.Method = WebRequestMethods.Http.Get;
                        httpWebRequest.Credentials = new NetworkCredential(ConfigurationManager.AppSettings["GiataUserName"], ConfigurationManager.AppSettings["GiataPassword"]);
                        HttpWebResponse response = (HttpWebResponse)httpWebRequest.GetResponse();

                        giataOutputStream = response.GetResponseStream();
                    }
                    catch (Exception exception)
                    {
                        newGiataHeaderInformationDataRow["ExceptionMessage"] =
                            $"Thread# {numberOfThread} -> Url is: {url}. Failed for {masterRecordModel.HotelStaticId} and exception is: {exception.Message}";

                        Console.WriteLine($"Thread# {numberOfThread} -> Failed Url is: {url}");
                    }

                    if (giataOutputStream == null)
                    {
                        newGiataHeaderInformationDataRow["GiataId"] = -1;
                    }
                    else if (giataOutputStream != null)
                    {
                        XmlDocument giataXmlDocument = new XmlDocument();

                        giataXmlDocument.Load(giataOutputStream);

                        XmlNode propertyXmlNode = giataXmlDocument.SelectSingleNode("descendant::properties/property");

                        if (propertyXmlNode == null)
                        {
                            newGiataHeaderInformationDataRow["GiataId"] = 0;
                        }
                        else if (propertyXmlNode != null)
                        {
                            string giataIdString = ((XmlElement)propertyXmlNode).GetAttribute("giataId");
                            int giataId = 0;

                            Int32.TryParse(giataIdString, out giataId);

                            newGiataHeaderInformationDataRow["GiataId"] = giataId;
                            //Console.WriteLine($"{url} -> {hotelCompanyModel.Gdsid} : {hotelCompanyModel.Accommodationid} - {giataId}");

                            string giataLastUpdated = ((XmlElement)propertyXmlNode).GetAttribute("lastUpdate");

                            newGiataHeaderInformationDataRow["LastUpdatedString"] = giataLastUpdated;

                            string[] lastUpdatedParts = giataLastUpdated.Split('+');

                            DateTime dt = DateTime.Parse(lastUpdatedParts[0]);

                            TimeSpan offSet = TimeSpan.Parse(lastUpdatedParts[1]);

                            dt = dt.AddHours(offSet.Hours).AddMinutes(offSet.Minutes).AddSeconds(offSet.Seconds);

                            newGiataHeaderInformationDataRow["LastUpdated"] = dt;

                            XmlNode propertyNameXmlNode = propertyXmlNode.SelectSingleNode("descendant::name");

                            if (propertyNameXmlNode != null)
                            {
                                newGiataHeaderInformationDataRow["GiataName"] = propertyNameXmlNode.InnerText;
                                //giataResponse.Name = propertyNameXmlNode.InnerText;
                            }

                            XmlNode cityXmlNode = propertyXmlNode.SelectSingleNode("descendant::city");

                            if (cityXmlNode != null)
                            {
                                int cityId = 0;

                                Int32.TryParse(((XmlElement)cityXmlNode).GetAttribute("cityId"), out cityId);

                                newGiataHeaderInformationDataRow["GiataCityId"] = cityId;

                                //giataResponse.CityId = cityId;

                                newGiataHeaderInformationDataRow["GiataCity"] = cityXmlNode.InnerText;

                                //giataResponse.City = cityXmlNode.InnerText;
                            }

                            XmlNode countryXmlNode = propertyXmlNode.SelectSingleNode("descendant::country");

                            if (countryXmlNode != null)
                            {
                                newGiataHeaderInformationDataRow["GiataCountry"] = countryXmlNode.InnerText;
                                //giataResponse.Country = countryXmlNode.InnerText;
                            }

                            XmlNodeList addressXmlNodeList = propertyXmlNode.SelectNodes("descendant::addresses");

                            if (addressXmlNodeList != null && addressXmlNodeList.Count > 0)
                            {
                                foreach (XmlNode addressXmlNode in addressXmlNodeList)
                                {
                                    XmlNodeList addressLineXmlNodeList =
                                        addressXmlNode.SelectNodes("descendant::addressLine");

                                    if (addressLineXmlNodeList != null)
                                    {
                                        foreach (XmlNode addressLineXmlNode in addressLineXmlNodeList)
                                        {
                                            string addressLineNumber =
                                                ((XmlElement)addressLineXmlNode).GetAttribute("addressLineNumber");

                                            if (addressLineNumber.Equals("1"))
                                            {
                                                newGiataHeaderInformationDataRow["GiataAddressLine1"] = addressLineXmlNode.InnerText;
                                                //giataAddress.AddressLineOne = addressLineXmlNode.InnerText;
                                            }
                                            else if (addressLineNumber.Equals("2"))
                                            {
                                                newGiataHeaderInformationDataRow["GiataAddressLine2"] = addressLineXmlNode.InnerText;
                                                //giataAddress.AddressLineTwo = addressLineXmlNode.InnerText;
                                            }
                                            else if (addressLineNumber.Equals("3"))
                                            {
                                                newGiataHeaderInformationDataRow["GiataAddressLine3"] = addressLineXmlNode.InnerText;
                                                //giataAddress.AddressLineThree = addressLineXmlNode.InnerText;
                                            }
                                            else if (addressLineNumber.Equals("4"))
                                            {
                                                newGiataHeaderInformationDataRow["GiataAddressLine4"] = addressLineXmlNode.InnerText;
                                                //giataAddress.AddressLineFour = addressLineXmlNode.InnerText;
                                            }
                                        }
                                    }



                                    XmlNode streetXmlNode = addressXmlNode.SelectSingleNode("descendant::street");

                                    if (streetXmlNode != null)
                                    {
                                        newGiataHeaderInformationDataRow["GiataStreet"] = streetXmlNode.InnerText;
                                        //giataAddress.Street = streetXmlNode.InnerText;
                                    }

                                    XmlNode streetNumberXmlNode = addressXmlNode.SelectSingleNode("descendant::streetNumber");

                                    if (streetNumberXmlNode != null)
                                    {
                                        newGiataHeaderInformationDataRow["GiataStreetNumber"] = streetNumberXmlNode.InnerText;
                                        //giataAddress.StreetNumber = streetNumberXmlNode.InnerText;
                                    }

                                    XmlNode cityNameXmlNode = addressXmlNode.SelectSingleNode("descendant::cityName");

                                    if (cityNameXmlNode != null)
                                    {
                                        newGiataHeaderInformationDataRow["GiataCityName"] = cityNameXmlNode.InnerText;
                                        //giataAddress.CityName = cityNameXmlNode.InnerText;
                                    }

                                    XmlNode postalCodeXmlNode = addressXmlNode.SelectSingleNode("descendant::postalCode");

                                    if (postalCodeXmlNode != null)
                                    {
                                        newGiataHeaderInformationDataRow["GiataPostalCode"] = postalCodeXmlNode.InnerText;
                                        //giataAddress.PoBox = postalCodeXmlNode.InnerText;
                                    }

                                    XmlNode addressCountryXmlNode = addressXmlNode.SelectSingleNode("descendant::country");

                                    if (addressCountryXmlNode != null)
                                    {
                                        newGiataHeaderInformationDataRow["GiataAddressCountry"] = addressCountryXmlNode.InnerText;
                                        //giataAddress.Country = addressCountryXmlNode.InnerText;
                                    }
                                }
                            }

                            XmlNode latitudeXmlNode =
                                propertyXmlNode.SelectSingleNode("descendant::geoCodes/geoCode/latitude");

                            if (latitudeXmlNode != null)
                            {
                                newGiataHeaderInformationDataRow["GiataLatitude"] = latitudeXmlNode.InnerText;
                                //giataResponse.Latitude = latitudeXmlNode.InnerText;
                            }

                            XmlNode longitudeXmlNode =
                                propertyXmlNode.SelectSingleNode("descendant::geoCodes/geoCode/longitude");

                            if (longitudeXmlNode != null)
                            {
                                newGiataHeaderInformationDataRow["GiataLongitude"] = longitudeXmlNode.InnerText;
                                //giataResponse.Longitude = longitudeXmlNode.InnerText;
                            }

                            XmlNodeList providerCodeXmlNodeList =
                                propertyXmlNode.SelectNodes("descendant::propertyCodes/provider");

                            if (providerCodeXmlNodeList != null)
                            {
                                foreach (XmlNode providerCodeXmlNode in providerCodeXmlNodeList)
                                {
                                    string providerCode =
                                            ((XmlElement)providerCodeXmlNode).GetAttribute("providerCode");

                                    string providerType =
                                        ((XmlElement)providerCodeXmlNode).GetAttribute("providerType");


                                    XmlNodeList codeXmlNodeList = providerCodeXmlNode.SelectNodes("descendant::code");

                                    if (codeXmlNodeList != null)
                                    {
                                        foreach (XmlNode codeXmlNode in codeXmlNodeList)
                                        {

                                            DataRow newGiataProviderInformationDataRow =
                                                giataProviderInformationDataTable.NewRow();

                                            XmlNode valueXmlNode = codeXmlNode.SelectSingleNode("descendant::value");

                                            if (valueXmlNode != null)
                                            {
                                                newGiataProviderInformationDataRow["ProviderCode"] = providerCode;
                                                newGiataProviderInformationDataRow["ProviderType"] = providerType;
                                                //if (_gdsIdToGiataProviderCode.ContainsValue(providerCode))
                                                //{
                                                //    newGiataProviderInformationDataRow["GdsId"] = _gdsIdToGiataProviderCode.FirstOrDefault(
                                                //        x => x.Value.ToLower().Equals(providerCode)).Key;

                                                //    newGiataProviderInformationDataRow["GdsName"] =
                                                //        gdsIdToGdsName[
                                                //            Int32.Parse(
                                                //                newGiataProviderInformationDataRow["GdsId"].ToString())];
                                                //}
                                                newGiataProviderInformationDataRow["MasterHotelId"] =
                                                    masterRecordModel.MasterHotelId;
                                                newGiataProviderInformationDataRow["HotelStaticId"] =
                                                    masterRecordModel.HotelStaticId;
                                                newGiataProviderInformationDataRow["GdsId"] =
                                                    masterRecordModel.GdsId;
                                                newGiataProviderInformationDataRow["GiataProviderCode"] =
                                                    masterRecordModel.GiataProviderCode;
                                                newGiataProviderInformationDataRow["AccommodationId"] =
                                                    masterRecordModel.AccommodationId;
                                                newGiataProviderInformationDataRow["RecordSource"] = "Giata";

                                                newGiataProviderInformationDataRow["GiataId"] = giataId;
                                                newGiataProviderInformationDataRow["Value"] = valueXmlNode.InnerText;
                                                //giataProviderInfo.CodeValues.Add(valueXmlNode.InnerText);
                                            }
                                            giataProviderInformationDataTable.Rows.Add(newGiataProviderInformationDataRow);
                                        }
                                    }
                                }
                            }


                        }
                    }
                    recordCount++;
                    giataHeaderInformationDataTable.Rows.Add(newGiataHeaderInformationDataRow);

                    if (recordCount % numberOfRecordsTobeInsertedIntoDbInBulk == 0 || (masterRecordModels.Count - recordCount < numberOfRecordsTobeInsertedIntoDbInBulk && masterRecordModels.Count - 1 == recordCount))
                    {
                        Console.WriteLine($"Thread#: {numberOfThread} has processed {recordCount} records.");

                        DataTable giataHeaderToBeInserted = giataHeaderInformationDataTable.Copy();
                        DataTable giataProviderToBeInserted = giataProviderInformationDataTable.Copy();

                        giataHeaderInformationDataTable.Rows.Clear();
                        giataProviderInformationDataTable.Rows.Clear();

                        BulkInsertIntoDb(giataHeaderToBeInserted, giataProviderToBeInserted, latitudeLongitudeConnectionString, numberOfThread);
                    }
                }

                Console.WriteLine("-----------------------------------------------------------------------");
                Console.WriteLine($"Thread#: {numberOfThread} Downloading and insertion of data completed.");
                Console.WriteLine("------------------------------------------------------------------------");

            }
            catch (Exception exception)
            {
                Console.WriteLine($"Thread#: {numberOfThread} exception is: {exception.Message}");
                throw new ApplicationException(exception.Message, exception.InnerException);
            }

            File.WriteAllLines(@"D:\" + numberOfThread + ".txt", status.ToArray());
        }

        private static DataTable CreateGiataHeaderInformationDataTable()
        {
            DataTable giataHeaderInformationDataTable = new DataTable();

            giataHeaderInformationDataTable.Columns.Add("HotelStaticId", typeof(int));
            giataHeaderInformationDataTable.Columns.Add("MasterHotelId", typeof(int));
            giataHeaderInformationDataTable.Columns.Add("GdsId", typeof(int));
            giataHeaderInformationDataTable.Columns.Add("GiataProviderCode", typeof(string));
            giataHeaderInformationDataTable.Columns.Add("AccommodationId", typeof(string));
            giataHeaderInformationDataTable.Columns.Add("RecordSource", typeof(string));
            giataHeaderInformationDataTable.Columns.Add("GiataId", typeof(int));
            giataHeaderInformationDataTable.Columns.Add("LastUpdatedString", typeof(string));
            giataHeaderInformationDataTable.Columns.Add("LastUpdated", typeof(DateTime));
            giataHeaderInformationDataTable.Columns.Add("GiataName", typeof(string));
            giataHeaderInformationDataTable.Columns.Add("GiataCityId", typeof(Int32));
            giataHeaderInformationDataTable.Columns.Add("GiataCity", typeof(string));
            giataHeaderInformationDataTable.Columns.Add("GiataCountry", typeof(string));
            giataHeaderInformationDataTable.Columns.Add("GiataAddressLine1", typeof(string));
            giataHeaderInformationDataTable.Columns.Add("GiataAddressLine2", typeof(string));
            giataHeaderInformationDataTable.Columns.Add("GiataAddressLine3", typeof(string));
            giataHeaderInformationDataTable.Columns.Add("GiataAddressLine4", typeof(string));
            giataHeaderInformationDataTable.Columns.Add("GiataStreet", typeof(string));
            giataHeaderInformationDataTable.Columns.Add("GiataStreetNumber", typeof(string));
            giataHeaderInformationDataTable.Columns.Add("GiataCityName", typeof(string));
            giataHeaderInformationDataTable.Columns.Add("GiataPostalCode", typeof(string));
            giataHeaderInformationDataTable.Columns.Add("GiataAddressCountry", typeof(string));
            giataHeaderInformationDataTable.Columns.Add("GiataLatitude", typeof(string));
            giataHeaderInformationDataTable.Columns.Add("GiataLongitude", typeof(string));
            giataHeaderInformationDataTable.Columns.Add("CreatedDate", typeof(DateTime));
            giataHeaderInformationDataTable.Columns.Add("ExceptionMessage", typeof(string));

            return giataHeaderInformationDataTable;
        }

        private static DataTable CreateGiataProviderInformationHeaderTable()
        {
            DataTable giataProviderInformationDataTable = new DataTable();

            giataProviderInformationDataTable.Columns.Add("HotelStaticId", typeof(int));
            giataProviderInformationDataTable.Columns.Add("MasterHotelId", typeof(int));
            giataProviderInformationDataTable.Columns.Add("GdsId", typeof(int));
            giataProviderInformationDataTable.Columns.Add("GiataProviderCode", typeof(string));
            giataProviderInformationDataTable.Columns.Add("AccommodationId", typeof(string));
            giataProviderInformationDataTable.Columns.Add("RecordSource", typeof(string));
            giataProviderInformationDataTable.Columns.Add("GiataId", typeof(int));
            giataProviderInformationDataTable.Columns.Add("ProviderCode", typeof(string));
            giataProviderInformationDataTable.Columns.Add("ProviderType", typeof(string));
            giataProviderInformationDataTable.Columns.Add("Value", typeof(string));
            giataProviderInformationDataTable.Columns.Add("NewSupplierHotelId", typeof(string));
            giataProviderInformationDataTable.Columns.Add("GdsCode", typeof(string));
            giataProviderInformationDataTable.Columns.Add("NewGdsId", typeof(int));

            return giataProviderInformationDataTable;
        }

        private static void BulkInsertIntoDb(DataTable giataHeaderInformationDataTable,
            DataTable giataProviderInformationDataTable, string latitudeAndLongitudeConnectionString, int numberOfThread)
        {


            using (SqlConnection sqlConnection = new SqlConnection(latitudeAndLongitudeConnectionString))
            {
                sqlConnection.Open();

                using (SqlBulkCopy sqlBulkCopy = new SqlBulkCopy(sqlConnection))
                {
                    sqlBulkCopy.DestinationTableName = ConfigurationManager.AppSettings["MasterRecordsGHITableName"];

                    DbDataReader dbDataReader = new DataTableReader(giataHeaderInformationDataTable);

                    sqlBulkCopy.WriteToServer(dbDataReader);
                }

                //Console.WriteLine($"{numberOfThread} insertion into GiataHeaderInformation_09_11_2016 completed.");

                using (SqlBulkCopy sqlBulkCopy = new SqlBulkCopy(sqlConnection))
                {
                    sqlBulkCopy.DestinationTableName = ConfigurationManager.AppSettings["MasterRecordsGPITableName"];

                    DbDataReader dbDataReader = new DataTableReader(giataProviderInformationDataTable);

                    sqlBulkCopy.WriteToServer(dbDataReader);
                }
            }
            if (giataHeaderInformationDataTable.Rows.Count != 100)
            {
                Console.WriteLine(
                    $"Thread# {numberOfThread} insertion into {ConfigurationManager.AppSettings["GiataHeaderInformationTable"]} completed for {giataHeaderInformationDataTable.Rows.Count} records in Header Information.");
            }
        }

        private static List<MasterRecordModel> GetMasterRecordModels(string connectionString)
        {
            List<MasterRecordModel> masterRecordModels = new List<MasterRecordModel>();

            try
            {
                using (SqlConnection sqlConnection = new SqlConnection(connectionString))
                {
                    sqlConnection.Open();

                    SqlCommand sqlSelectCommand = new SqlCommand(ConfigurationManager.AppSettings["SPGetMasterRecordsList"], sqlConnection)
                    {
                        CommandType = CommandType.StoredProcedure
                    };

                    SqlParameter sqlParameter = new SqlParameter("InsertRemainingRecords", SqlDbType.Int)
                    {
                        Value = Int32.Parse(ConfigurationManager.AppSettings["InsertRemainingRecords"])
                    };

                    sqlSelectCommand.Parameters.Add(sqlParameter);

                    SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(sqlSelectCommand);

                    DataSet resultDataSet = new DataSet();

                    sqlDataAdapter.Fill(resultDataSet);

                    if (resultDataSet.Tables.Count > 0)
                    {
                        foreach (DataRow row in resultDataSet.Tables[0].Rows)
                        {
                            MasterRecordModel masterRecordModel = new MasterRecordModel();

                            masterRecordModel.AccommodationId = row["AccommodationId"] != DBNull.Value
                                ? row["AccommodationId"].ToString()
                                : String.Empty;

                            masterRecordModel.GdsId = row["GdsId"] != DBNull.Value
                                ? Int32.Parse(row["GdsId"].ToString())
                                : -1;

                            masterRecordModel.GiataProviderCode = row["GiataProviderCode"] != DBNull.Value
                                ? row["GiataProviderCode"].ToString()
                                : String.Empty;

                            masterRecordModel.HotelStaticId = row["HotelStaticId"] != DBNull.Value
                                ? Int32.Parse(row["HotelStaticId"].ToString())
                                : -1;

                            masterRecordModel.MasterHotelId = row["MasterHotelId"] != DBNull.Value
                                ? Int32.Parse(row["MasterHotelId"].ToString())
                                : -1;

                            masterRecordModel.RecordSource = row["RecordSource"] != DBNull.Value
                                ? row["RecordSource"].ToString()
                                : String.Empty;

                            masterRecordModels.Add(masterRecordModel);
                        }
                    }
                }
            }
            catch (Exception exception)
            {
                Console.WriteLine($"Exception occured in GetMasterRecordModels. Message: {exception.Message}. StackTrace: {exception.StackTrace}");
            }

            return masterRecordModels;
        }
    }
}
